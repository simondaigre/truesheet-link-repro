import React from 'react';
import type { DrawerDirection, KeyboardViewport } from './types';
export declare function useSnapPoints({ activeSnapPointProp, setActiveSnapPointProp, snapPoints, drawerRef, overlayRef, fadeFromIndex, onSnapPointChange, direction, container, snapToSequentialPoint, isOpen, contentHeight, detachedOffset, maxContentHeight, peekHeight, initialAnimated, keyboardViewport, }: {
    activeSnapPointProp?: number | string | null;
    setActiveSnapPointProp?(snapPoint: number | null | string): void;
    snapPoints?: (number | string)[];
    fadeFromIndex?: number;
    drawerRef: React.RefObject<HTMLDivElement | null>;
    overlayRef: React.RefObject<HTMLDivElement | null>;
    onSnapPointChange(activeSnapPointIndex: number, animated: boolean): void;
    direction?: DrawerDirection;
    container?: HTMLElement | null | undefined;
    snapToSequentialPoint?: boolean;
    isOpen?: boolean;
    contentHeight?: number;
    detachedOffset?: number;
    maxContentHeight?: number;
    peekHeight?: number;
    initialAnimated?: boolean;
    keyboardViewport?: KeyboardViewport;
}): {
    isLastSnapPoint: true | null;
    activeSnapPoint: string | number | null | undefined;
    shouldFade: boolean;
    getPercentageDragged: (absDraggedDistance: number, isDraggingDown: boolean) => number | null;
    setActiveSnapPoint: React.Dispatch<React.SetStateAction<string | number | null | undefined>>;
    activeSnapPointIndex: number | null;
    onRelease: ({ draggedDistance, closeDrawer, velocity, dismissible, dismissThreshold, }: {
        draggedDistance: number;
        closeDrawer: () => void;
        velocity: number;
        dismissible: boolean;
        dismissThreshold: "half" | "short";
    }) => void;
    onDrag: ({ draggedDistance }: {
        draggedDistance: number;
    }) => void;
    snapPointsOffset: number[];
};
//# sourceMappingURL=use-snap-points.d.ts.map