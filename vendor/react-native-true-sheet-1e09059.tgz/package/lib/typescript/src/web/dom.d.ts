import type { View } from 'react-native';
/**
 * Resolves a React Native web `View` ref value to its underlying DOM element —
 * RN-web refs expose the host DOM node directly.
 */
export declare const getDOMElement: (view: View | null) => HTMLElement | null;
//# sourceMappingURL=dom.d.ts.map