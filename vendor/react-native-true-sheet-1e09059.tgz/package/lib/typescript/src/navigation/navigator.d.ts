import type { TrueSheetNavigationOptions, TrueSheetNavigatorContentExtraProps, TrueSheetStandardEventMap } from './types';
/**
 * Framework-agnostic TrueSheet navigator.
 * Wired into React Navigation via `./index` and Expo Router via `./expo-router`.
 */
export declare const trueSheetNavigator: import("standard-navigation").StandardNavigator<TrueSheetNavigationOptions, TrueSheetStandardEventMap, TrueSheetNavigatorContentExtraProps>;
//# sourceMappingURL=navigator.d.ts.map