import type { TrueSheetScreenProps } from './types';
export declare const ReanimatedTrueSheetScreen: ({ detentIndex, resizeKey, dispatch, emit, routeKey, closing, detents, children, positionChangeHandler, ...sheetProps }: TrueSheetScreenProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=ReanimatedTrueSheetScreen.d.ts.map