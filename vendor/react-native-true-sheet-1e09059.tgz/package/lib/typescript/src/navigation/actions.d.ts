export type TrueSheetActionType = {
    type: 'PUSH';
    payload: {
        name: string;
        params?: object;
    };
    source?: string;
    target?: string;
} | {
    type: 'POP';
    payload: {
        count: number;
    };
    source?: string;
    target?: string;
} | {
    type: 'POP_TO';
    payload: {
        name: string;
        params?: object;
        merge?: boolean;
    };
    source?: string;
    target?: string;
} | {
    type: 'POP_TO_TOP';
    source?: string;
    target?: string;
} | {
    type: 'REPLACE';
    payload: {
        name: string;
        params?: object;
    };
    source?: string;
    target?: string;
} | {
    type: 'GO_BACK';
    source?: string;
    target?: string;
} | {
    type: 'RESIZE';
    index: number;
    source?: string;
    target?: string;
} | {
    type: 'DISMISS';
    source?: string;
    target?: string;
} | {
    type: 'REMOVE';
    source?: string;
    target?: string;
};
/**
 * Action creators for the TrueSheet navigator.
 * Plain objects matching `StackActions` shapes, plus sheet-specific actions.
 */
export declare const TrueSheetActions: {
    push: (name: string, params?: object) => TrueSheetActionType;
    pop: (count?: number) => TrueSheetActionType;
    popTo: (name: string, params?: object, options?: {
        merge?: boolean;
    }) => TrueSheetActionType;
    popToTop: () => TrueSheetActionType;
    replace: (name: string, params?: object) => TrueSheetActionType;
    resize: (index: number) => TrueSheetActionType;
    dismiss: () => TrueSheetActionType;
    remove: () => TrueSheetActionType;
};
//# sourceMappingURL=actions.d.ts.map