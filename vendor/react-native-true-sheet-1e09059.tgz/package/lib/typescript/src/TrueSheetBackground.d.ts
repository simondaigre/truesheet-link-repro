import type { TrueSheetProps } from './TrueSheet.types';
export declare const TrueSheetBackground: ({ background, backgroundStyle, }: Pick<TrueSheetProps, "background" | "backgroundStyle">) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=TrueSheetBackground.d.ts.map