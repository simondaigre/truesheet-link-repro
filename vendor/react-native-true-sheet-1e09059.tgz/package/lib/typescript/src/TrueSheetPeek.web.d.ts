import { type RefObject } from 'react';
import { View, type ViewProps } from 'react-native';
/**
 * Registers a peek with the owning TrueSheet so it can measure the peek live.
 * @internal
 */
export interface TrueSheetPeekContextValue {
    contentRef: RefObject<View | null>;
    attachPeek: (view: View) => void;
    detachPeek: (view: View) => void;
    measurePeek: (view: View) => void;
}
export declare const TrueSheetPeekContext: import("react").Context<TrueSheetPeekContextValue | null>;
/**
 * Distance from the top of the content view to the bottom of the peek view,
 * so the peek view's offset within the content (padding, views above it)
 * counts toward the peek detent. Both rects live in the drawer's transformed
 * subtree, so an in-flight translate cancels out of the delta. Rounded so the
 * sub-pixel noise of a mid-transition measurement doesn't register as a
 * change — the content re-measures every frame while the snap animates, and
 * a new value would restart the snap.
 * @internal
 */
export declare const measurePeekContentHeight: (peekElement: HTMLElement, contentElement: HTMLElement) => number;
/**
 * Wrapper component that marks its children as the sheet's peek content.
 * When rendered within a `TrueSheet`, the `"peek"` detent reveals everything
 * from the top of the sheet through the bottom of this component — content
 * below it stays hidden until the sheet is expanded.
 */
export declare const TrueSheetPeek: ({ onLayout, ...rest }: ViewProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=TrueSheetPeek.web.d.ts.map