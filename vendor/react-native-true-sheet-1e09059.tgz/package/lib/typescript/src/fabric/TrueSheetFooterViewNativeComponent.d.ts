import type { CodegenTypes, ViewProps } from 'react-native';
export interface NativeProps extends ViewProps {
    autoBottomInset?: CodegenTypes.WithDefault<boolean, false>;
}
declare const _default: import("react-native").HostComponent<NativeProps>;
export default _default;
//# sourceMappingURL=TrueSheetFooterViewNativeComponent.d.ts.map