'use client';

import React from 'react';

import * as DialogPrimitive from '@radix-ui/react-dialog';
import { Presence } from '@radix-ui/react-presence';

import { DrawerContext, useDrawerContext, type DragEvent } from './context';
import './style.css';

import { isIOS, isMobileFirefox } from './browser';
import {
  BORDER_RADIUS,
  CLOSE_THRESHOLD,
  DISMISS_ATTEMPT_THRESHOLD,
  DRAG_CLASS,
  NESTED_DISPLACEMENT,
  SCROLL_LOCK_TIMEOUT,
  TRANSITIONS,
  VELOCITY_THRESHOLD,
  WINDOW_TOP_OFFSET,
} from './constants';
import {
  dampenValue,
  getSnapPointTransform,
  getTranslate,
  isVertical,
  reset,
  set,
} from './helpers';
import type { DrawerDirection, KeyboardViewport } from './types';
import { useComposedRefs } from './use-composed-refs';
import { useControllableState } from './use-controllable-state';
import { usePositionFixed } from './use-position-fixed';
import { isInput, isScrollable, usePreventScroll } from './use-prevent-scroll';
import { useScaleBackground } from './use-scale-background';
import { useSnapPoints } from './use-snap-points';

export interface WithFadeFromProps {
  /**
   * Array of numbers from 0 to 100 that corresponds to % of the screen a given snap point should take up.
   * Should go from least visible. Example `[0.2, 0.5, 0.8]`.
   * You can also use px values, which doesn't take screen height into account.
   */
  snapPoints: (number | string)[];
  /**
   * Index of a `snapPoint` from which the overlay fade should be applied. Defaults to the last snap point.
   */
  fadeFromIndex: number;
}

export interface WithoutFadeFromProps {
  /**
   * Array of numbers from 0 to 100 that corresponds to % of the screen a given snap point should take up.
   * Should go from least visible. Example `[0.2, 0.5, 0.8]`.
   * You can also use px values, which doesn't take screen height into account.
   */
  snapPoints?: (number | string)[];
  fadeFromIndex?: never;
}

export type DialogProps = {
  activeSnapPoint?: number | string | null;
  setActiveSnapPoint?: (snapPoint: number | string | null) => void;
  children?: React.ReactNode;
  open?: boolean;
  /**
   * Number between 0 and 1 that determines when the drawer should be closed.
   * Example: threshold of 0.5 would close the drawer if the user swiped for 50% of the height of the drawer or more.
   * @default 0.25
   */
  closeThreshold?: number;
  /**
   * When `true` the `body` doesn't get any styles assigned from Vaul
   */
  noBodyStyles?: boolean;
  onOpenChange?: (open: boolean) => void;
  shouldScaleBackground?: boolean;
  /**
   * When `false` we don't change body's background color when the drawer is open.
   * @default true
   */
  setBackgroundColorOnScale?: boolean;
  /**
   * Duration for which the drawer is not draggable after scrolling content inside of the drawer.
   * @default 500ms
   */
  scrollLockTimeout?: number;
  /**
   * When `true`, don't move the drawer upwards if there's space, but rather only change it's height so it's fully scrollable when the keyboard is open
   */
  fixed?: boolean;
  /**
   * When `true` only allows the drawer to be dragged by the `<Drawer.Handle />` component.
   * @default false
   */
  handleOnly?: boolean;
  /**
   * When `false` dragging, clicking outside, pressing esc, etc. will not close the drawer.
   * Use this in comination with the `open` prop, otherwise you won't be able to open/close the drawer.
   * @default true
   */
  dismissible?: boolean;
  /**
   * How far the drawer must be dragged past its first snap point to close.
   * `'half'` closes past half of it, `'short'` on a short drag or any fling.
   * @default 'half'
   */
  dismissThreshold?: 'half' | 'short';
  /**
   * Called when the user tries to close a non-dismissible drawer — dragging down
   * at the first snap point, pressing escape, or tapping the handle of a
   * single-snap-point drawer. Overlay clicks don't count, mirroring iOS.
   */
  onDismissAttempt?: () => void;
  /**
   * When `false` the drawer can't be dragged by the user. Programmatic snap-point
   * changes still animate. Defaults to `true`.
   */
  draggable?: boolean;
  onDrag?: (event: React.PointerEvent<HTMLDivElement>, percentageDragged: number) => void;
  onRelease?: (event: React.PointerEvent<HTMLDivElement>, open: boolean) => void;
  /**
   * When `false` it allows to interact with elements outside of the drawer without closing it.
   * @default true
   */
  modal?: boolean;
  nested?: boolean;
  onClose?: () => void;
  /**
   * Direction of the drawer. Can be `top` or `bottom`, `left`, `right`.
   * @default 'bottom'
   */
  direction?: 'top' | 'bottom' | 'left' | 'right';
  /**
   * Opened by default, skips initial enter animation. Still reacts to `open` state changes
   * @default false
   */
  defaultOpen?: boolean;
  /**
   * When set to `true` prevents scrolling on the document body on mount, and restores it on unmount.
   * @default false
   */
  disablePreventScroll?: boolean;
  /**
   * When `true` Vaul will reposition inputs rather than scroll then into view if the keyboard is in the way.
   * Setting it to `false` will fall back to the default browser behavior.
   * @default true when {@link snapPoints} is defined
   */
  repositionInputs?: boolean;
  /**
   * Disabled velocity based swiping for snap points.
   * This means that a snap point won't be skipped even if the velocity is high enough.
   * Useful if each snap point in a drawer is equally important.
   * @default false
   */
  snapToSequentialPoint?: boolean;
  container?: HTMLElement | null;
  /**
   * Gets triggered after the open or close animation ends, it receives an `open` argument with the `open` state of the drawer by the time the function was triggered.
   * Useful to revert any state changes for example.
   */
  onAnimationEnd?: (open: boolean) => void;
  /**
   * Fires on every animation frame while the drawer is open with the drawer's
   * current top edge in the viewport (px). Emits during drag, snap, and the
   * open/close transitions.
   */
  onPositionChange?: (position: number) => void;
  preventScrollRestoration?: boolean;
  autoFocus?: boolean;
  /**
   * Renders the drawer as a floating card offset from the bottom edge so it
   * doesn't visually attach to the viewport. Snap points are computed against
   * the reduced floating area, so {@link detachedOffset} is preserved during
   * drag and snap.
   * @default false
   */
  detached?: boolean;
  /**
   * Gap (in px) between the drawer's bottom edge and the viewport bottom when
   * {@link detached} is `true`.
   * @default 0
   */
  detachedOffset?: number;
  /**
   * Corner radius (in px) applied to the clip wrapper's bottom when
   * {@link detached} is `true`, so the floating card's bottom edge stays
   * rounded while it's clipped at the floating anchor.
   * @default 0
   */
  detachedRadius?: number;
  /**
   * Extra styles merged into the detached clip wrapper. Use this to match the
   * wrapper's horizontal bounds to the drawer's on desktop (e.g. `maxWidth` +
   * auto margins) so its rounded-bottom clip aligns with the drawer.
   */
  detachedWrapperStyle?: React.CSSProperties;
  /**
   * Caps the visible sheet height (in px) so full and 'auto' snap points
   * respect a user-specified ceiling.
   */
  maxContentHeight?: number;
  /**
   * Resolved height (in px) for the 'peek' snap point — the caller measures
   * its header/footer and passes the combined height.
   */
  peekHeight?: number;
  /**
   * When `false` the first snap on mount is applied without a transition so
   * the sheet appears at its target detent instantly. Defaults to `true`.
   */
  initialAnimated?: boolean;
  /**
   * Fires when the auto-size wrapper's measured content height changes.
   * Useful for callers that want to size the surrounding card to fit
   * content (e.g. iPad-style form sheets).
   */
  onContentHeightChange?: (height: number) => void;
  /**
   * Overrides the measured content height used to resolve the 'auto' snap
   * point. Used when the caller bounds the content to the visible sheet
   * (e.g. a plugged scrollable) so the auto-size wrapper can't be measured
   * from natural flow.
   */
  contentHeight?: number;
  /**
   * Lays the drawer out in the visual viewport above a soft keyboard. The
   * wrapper and snap offsets fit the visible area, while fractional snap
   * points keep scaling against the full layout height.
   */
  keyboardViewport?: KeyboardViewport;
} & (WithFadeFromProps | WithoutFadeFromProps);

export function Root({
  open: openProp,
  onOpenChange,
  children,
  onDrag: onDragProp,
  onRelease: onReleaseProp,
  snapPoints,
  shouldScaleBackground = false,
  setBackgroundColorOnScale = true,
  closeThreshold = CLOSE_THRESHOLD,
  scrollLockTimeout = SCROLL_LOCK_TIMEOUT,
  dismissible = true,
  dismissThreshold = 'half',
  onDismissAttempt,
  draggable = true,
  handleOnly = false,
  fadeFromIndex = snapPoints && snapPoints.length - 1,
  activeSnapPoint: activeSnapPointProp,
  setActiveSnapPoint: setActiveSnapPointProp,
  fixed,
  modal = true,
  onClose,
  nested,
  noBodyStyles = false,
  direction = 'bottom',
  defaultOpen = false,
  disablePreventScroll = true,
  snapToSequentialPoint = false,
  preventScrollRestoration = false,
  repositionInputs = true,
  onAnimationEnd,
  onPositionChange,
  container,
  autoFocus = false,
  detached = false,
  detachedOffset = 0,
  detachedRadius = 0,
  detachedWrapperStyle,
  maxContentHeight,
  peekHeight,
  initialAnimated = true,
  onContentHeightChange,
  contentHeight: contentHeightProp,
  keyboardViewport,
}: DialogProps) {
  const [isOpen = false, setIsOpen] = useControllableState({
    defaultProp: defaultOpen,
    prop: openProp,
    onChange: (o: boolean) => {
      onOpenChange?.(o);

      if (!o && !nested) {
        restorePositionSetting();
      }

      setTimeout(() => {
        onAnimationEnd?.(o);
      }, TRANSITIONS.DURATION * 1000);
    },
  });
  const [hasBeenOpened, setHasBeenOpened] = React.useState<boolean>(false);
  const [isDragging, setIsDragging] = React.useState<boolean>(false);
  const [justReleased, setJustReleased] = React.useState<boolean>(false);
  const overlayRef = React.useRef<HTMLDivElement>(null);
  const openTime = React.useRef<Date | null>(null);
  const dragStartTime = React.useRef<Date | null>(null);
  const dragEndTime = React.useRef<Date | null>(null);
  const lastTimeDragPrevented = React.useRef<Date | null>(null);
  const isAllowedToDrag = React.useRef<boolean>(false);
  const nestedOpenChangeTimer = React.useRef<NodeJS.Timeout | null>(null);
  const pointerStart = React.useRef(0);
  const dismissAttempted = React.useRef(false);
  const keyboardIsOpen = React.useRef(false);
  const shouldAnimate = React.useRef(!defaultOpen);
  const hasPresented = React.useRef(false);
  const previousDiffFromInitial = React.useRef(0);
  const drawerRef = React.useRef<HTMLDivElement>(null);
  const drawerHeightRef = React.useRef(drawerRef.current?.getBoundingClientRect().height || 0);
  const drawerWidthRef = React.useRef(drawerRef.current?.getBoundingClientRect().width || 0);
  const initialDrawerHeight = React.useRef(0);
  const [measuredContentHeight, setContentHeight] = React.useState(0);
  const contentHeight = contentHeightProp ?? measuredContentHeight;

  const onContentHeightChangeRef = React.useRef(onContentHeightChange);
  React.useEffect(() => {
    onContentHeightChangeRef.current = onContentHeightChange;
  });
  React.useEffect(() => {
    onContentHeightChangeRef.current?.(measuredContentHeight);
  }, [measuredContentHeight]);

  const onSnapPointChange = React.useCallback((activeSnapPointIndex: number, animated: boolean) => {
    // Change openTime ref when we reach the last snap point to prevent dragging for 500ms incase it's scrollable.
    if (snapPoints && activeSnapPointIndex === snapPointsOffset.length - 1)
      openTime.current = new Date();
    // Instant snaps do not emit transition events for position tracking.
    if (!animated && drawerRef.current) {
      onPositionChangeRef.current?.(drawerRef.current.getBoundingClientRect().top);
    }
  }, []);

  const {
    activeSnapPoint,
    activeSnapPointIndex,
    setActiveSnapPoint,
    onRelease: onReleaseSnapPoints,
    snapPointsOffset,
    onDrag: onDragSnapPoints,
    shouldFade,
    getPercentageDragged: getSnapPointsPercentageDragged,
  } = useSnapPoints({
    snapPoints,
    activeSnapPointProp,
    setActiveSnapPointProp,
    drawerRef,
    fadeFromIndex,
    overlayRef,
    onSnapPointChange,
    direction,
    container,
    snapToSequentialPoint,
    isOpen,
    contentHeight,
    detachedOffset: detached ? detachedOffset : 0,
    maxContentHeight,
    peekHeight,
    initialAnimated,
    keyboardViewport,
  });

  usePreventScroll({
    isDisabled:
      !isOpen ||
      isDragging ||
      !modal ||
      justReleased ||
      !hasBeenOpened ||
      !repositionInputs ||
      !disablePreventScroll,
  });

  const { restorePositionSetting } = usePositionFixed({
    isOpen,
    modal,
    nested: nested ?? false,
    hasBeenOpened,
    preventScrollRestoration,
    noBodyStyles,
  });

  // While the sheet itself is being dragged, scrollables in the touched chain
  // are frozen (overflow: hidden). Touch browsers latch the scroll gesture at
  // touchstart and ignore preventDefault once scrolling has started, so making
  // the scroller non-scrollable mid-gesture is the only reliable way to keep
  // the content from panning along with the sheet.
  const frozenScrollablesRef = React.useRef<
    { element: HTMLElement; overflowX: string; overflowY: string }[] | null
  >(null);

  function freezeScrollables(target: EventTarget) {
    if (frozenScrollablesRef.current) return;
    const frozen: { element: HTMLElement; overflowX: string; overflowY: string }[] = [];
    let element = target instanceof HTMLElement ? target : null;
    while (element && element !== drawerRef.current) {
      if (isScrollable(element)) {
        frozen.push({
          element,
          overflowX: element.style.overflowX,
          overflowY: element.style.overflowY,
        });
        element.style.overflowX = 'hidden';
        element.style.overflowY = 'hidden';
      }
      element = element.parentElement;
    }
    frozenScrollablesRef.current = frozen;
  }

  function unfreezeScrollables() {
    const frozen = frozenScrollablesRef.current;
    if (!frozen) return;
    frozenScrollablesRef.current = null;
    for (const { element, overflowX, overflowY } of frozen) {
      element.style.overflowX = overflowX;
      element.style.overflowY = overflowY;
    }
  }

  function getScale() {
    return (window.innerWidth - WINDOW_TOP_OFFSET) / window.innerWidth;
  }

  function onPress(event: React.PointerEvent<HTMLDivElement>) {
    if (!draggable) return;
    if (!dismissible && !snapPoints) return;
    if (drawerRef.current && !drawerRef.current.contains(event.target as Node)) return;

    drawerHeightRef.current = drawerRef.current?.getBoundingClientRect().height || 0;
    drawerWidthRef.current = drawerRef.current?.getBoundingClientRect().width || 0;
    setIsDragging(true);
    dragStartTime.current = new Date();

    // iOS doesn't trigger mouseUp after scrolling so we need to listen to touched in order to disallow dragging
    if (isIOS()) {
      window.addEventListener('touchend', () => (isAllowedToDrag.current = false), { once: true });
    }
    // Ensure we maintain correct pointer capture even when going outside of the drawer
    (event.target as HTMLElement).setPointerCapture(event.pointerId);

    pointerStart.current = isVertical(direction) ? event.pageY : event.pageX;
  }

  function shouldDrag(el: EventTarget, isDraggingInDirection: boolean) {
    let element = el as HTMLElement;
    const highlightedText = window.getSelection()?.toString();
    const swipeAmount = drawerRef.current ? getTranslate(drawerRef.current, direction) : null;
    const date = new Date();

    // Fixes https://github.com/emilkowalski/vaul/issues/483
    if (element.tagName === 'SELECT') {
      return false;
    }

    if (element.hasAttribute('data-vaul-no-drag') || element.closest('[data-vaul-no-drag]')) {
      return false;
    }

    if (direction === 'right' || direction === 'left') {
      return true;
    }

    // Allow scrolling when animating
    if (openTime.current && date.getTime() - openTime.current.getTime() < 500) {
      return false;
    }

    if (swipeAmount !== null) {
      // Translated past the drag threshold → keep dragging. Below the last
      // snap point the threshold is 0, so the sheet always wins over content
      // scrolling. At the last snap point the threshold is its resting
      // translate — which can still be > 0 when the max detent < 1 — so an
      // at-rest sheet falls through to the scroll checks and content
      // scrolling wins, matching native. Mid-drag/mid-animation the sheet is
      // displaced past rest and still wins.
      const atLastSnapPoint = snapPoints && activeSnapPointIndex === snapPoints.length - 1;
      const restOffset = atLastSnapPoint ? (snapPointsOffset?.[activeSnapPointIndex!] ?? 0) : 0;
      if (direction === 'bottom' ? swipeAmount > restOffset + 1 : swipeAmount < restOffset - 1) {
        return true;
      }
    }

    // Don't drag if there's highlighted text
    if (highlightedText && highlightedText.length > 0) {
      return false;
    }

    // Disallow dragging if drawer was scrolled within `scrollLockTimeout`.
    // Don't re-arm the timestamp here — a prevented drag attempt is not a
    // scroll, and re-arming would keep the lock alive for as long as the
    // finger moves, deadening the whole gesture instead of just the first
    // `scrollLockTimeout` ms after the last real scroll.
    if (
      lastTimeDragPrevented.current &&
      date.getTime() - lastTimeDragPrevented.current.getTime() < scrollLockTimeout &&
      swipeAmount === 0
    ) {
      return false;
    }

    if (isDraggingInDirection) {
      lastTimeDragPrevented.current = date;

      // We are dragging down so we should allow scrolling
      return false;
    }

    // Keep climbing up the DOM tree as long as there's a parent
    while (element) {
      // Check if the element is scrollable
      if (element.scrollHeight > element.clientHeight) {
        // `> 0`, not `!== 0`: Safari reports a negative scrollTop during the
        // rubber-band bounce at the top — that's "at the top" for drag
        // purposes, and treating it as scrolled would arm the scroll lock and
        // delay the sheet drag until the bounce fully settles.
        if (element.scrollTop > 0) {
          lastTimeDragPrevented.current = new Date();

          // The element is scrollable and not scrolled to the top, so don't drag
          return false;
        }

        if (element.getAttribute('role') === 'dialog') {
          return true;
        }
      }

      // Move up to the parent element
      element = element.parentNode as HTMLElement;
    }

    // No scrollable parents not scrolled to the top found, so drag
    return true;
  }

  function drag(event: DragEvent, pointerEvent?: React.PointerEvent<HTMLDivElement>) {
    if (!drawerRef.current) {
      return;
    }

    // We need to know how much of the drawer has been dragged in percentages so that we can transform background accordingly
    if (isDragging) {
      const directionMultiplier = direction === 'bottom' || direction === 'right' ? 1 : -1;
      const draggedDistance =
        (pointerStart.current - (isVertical(direction) ? event.pageY : event.pageX)) *
        directionMultiplier;
      const isDraggingInDirection = draggedDistance > 0;

      // Pre condition for disallowing dragging in the close direction.
      const noCloseSnapPointsPreCondition = snapPoints && !dismissible && !isDraggingInDirection;

      // Disallow dragging down to close when first snap point is the active one and dismissible prop is set to false.
      if (noCloseSnapPointsPreCondition && activeSnapPointIndex === 0) {
        // The drawer stays put. Remember a deliberate pull that would otherwise
        // have dragged it (content at its top) so release() can report it.
        if (
          -draggedDistance > DISMISS_ATTEMPT_THRESHOLD &&
          (isAllowedToDrag.current || shouldDrag(event.target, isDraggingInDirection))
        ) {
          dismissAttempted.current = true;
        }
        return;
      }

      // We need to capture last time when drag with scroll was triggered and have a timeout between
      const absDraggedDistance = Math.abs(draggedDistance);
      const wrapper = document.querySelector('[data-vaul-drawer-wrapper]');
      const drawerDimension =
        direction === 'bottom' || direction === 'top'
          ? drawerHeightRef.current
          : drawerWidthRef.current;

      // Calculate the percentage dragged, where 1 is the closed position
      let percentageDragged = absDraggedDistance / drawerDimension;
      const snapPointPercentageDragged = getSnapPointsPercentageDragged(
        absDraggedDistance,
        isDraggingInDirection
      );

      if (snapPointPercentageDragged !== null) {
        percentageDragged = snapPointPercentageDragged;
      }

      // Disallow close dragging beyond the smallest snap point.
      if (noCloseSnapPointsPreCondition && percentageDragged >= 1) {
        return;
      }

      if (!isAllowedToDrag.current) {
        if (!shouldDrag(event.target, isDraggingInDirection)) return;
        drawerRef.current.classList.add(DRAG_CLASS);
        // If shouldDrag gave true once after pressing down on the drawer, we set isAllowedToDrag to true and it will remain true until we let go, there's no reason to disable dragging mid way, ever, and that's the solution to it
        isAllowedToDrag.current = true;
        // Touch pans latched onto a scroller would keep scrolling the content
        // along with the sheet drag — freeze them for the drag's duration.
        if (event.pointerType !== 'mouse') freezeScrollables(event.target);
        // Drag can engage mid-gesture (content scrolled back to its top under
        // the same finger, or the scroll lock expiring). Re-anchor and start
        // moving on the next tick so the sheet tracks the finger from here
        // instead of jumping by the distance the gesture already consumed.
        pointerStart.current = isVertical(direction) ? event.pageY : event.pageX;
        return;
      }
      set(drawerRef.current, {
        transition: 'none',
      });

      set(overlayRef.current, {
        transition: 'none',
      });

      if (pointerEvent) onDragProp?.(pointerEvent, percentageDragged);

      if (snapPoints) {
        onDragSnapPoints({ draggedDistance });
      }

      // Run this only if snapPoints are not defined or if we are at the last snap point (highest one)
      if (isDraggingInDirection && !snapPoints) {
        const dampenedDraggedDistance = dampenValue(draggedDistance);

        const translateValue = Math.min(dampenedDraggedDistance * -1, 0) * directionMultiplier;
        set(drawerRef.current, {
          transform: isVertical(direction)
            ? `translate3d(0, ${translateValue}px, 0)`
            : `translate3d(${translateValue}px, 0, 0)`,
        });
        return;
      }

      const opacityValue = 1 - percentageDragged;

      if (shouldFade || (fadeFromIndex && activeSnapPointIndex === fadeFromIndex - 1)) {
        set(
          overlayRef.current,
          {
            opacity: `${opacityValue}`,
            transition: 'none',
          },
          true
        );
      }

      if (wrapper && overlayRef.current && shouldScaleBackground) {
        // Calculate percentageDragged as a fraction (0 to 1)
        const scaleValue = Math.min(getScale() + percentageDragged * (1 - getScale()), 1);
        const borderRadiusValue = 8 - percentageDragged * 8;

        const translateValue = Math.max(0, 14 - percentageDragged * 14);

        set(
          wrapper,
          {
            borderRadius: `${borderRadiusValue}px`,
            transform: isVertical(direction)
              ? `scale(${scaleValue}) translate3d(0, ${translateValue}px, 0)`
              : `scale(${scaleValue}) translate3d(${translateValue}px, 0, 0)`,
            transition: 'none',
          },
          true
        );
      }

      if (!snapPoints) {
        const translateValue = absDraggedDistance * directionMultiplier;

        set(drawerRef.current, {
          transform: isVertical(direction)
            ? `translate3d(0, ${translateValue}px, 0)`
            : `translate3d(${translateValue}px, 0, 0)`,
        });
      }
    }
  }

  React.useEffect(() => {
    window.requestAnimationFrame(() => {
      shouldAnimate.current = true;
    });
  }, []);

  // Reset to the first snap point on every open so a prior session's active snap
  // (kept in state by `useControllableState` after dismissal) doesn't leak into
  // the next present. Skipped when `activeSnapPoint` is controlled externally.
  React.useEffect(() => {
    if (isOpen && snapPoints && activeSnapPointProp === undefined) {
      setActiveSnapPoint(snapPoints[0]);
    }
  }, [isOpen]);

  const onPositionChangeRef = React.useRef(onPositionChange);
  React.useEffect(() => {
    onPositionChangeRef.current = onPositionChange;
  });

  React.useEffect(() => {
    function onVisualViewportChange() {
      if (!drawerRef.current || !repositionInputs) return;

      const focusedElement = document.activeElement as HTMLElement;
      if (isInput(focusedElement) || keyboardIsOpen.current) {
        const visualViewportHeight = window.visualViewport?.height || 0;
        const totalHeight = window.innerHeight;
        // This is the height of the keyboard
        let diffFromInitial = totalHeight - visualViewportHeight;
        const drawerHeight = drawerRef.current.getBoundingClientRect().height || 0;
        // Adjust drawer height only if it's tall enough
        const isTallEnough = drawerHeight > totalHeight * 0.8;

        if (!initialDrawerHeight.current) {
          initialDrawerHeight.current = drawerHeight;
        }
        const offsetFromTop = drawerRef.current.getBoundingClientRect().top;

        // visualViewport height may change due to somq e subtle changes to the keyboard. Checking if the height changed by 60 or more will make sure that they keyboard really changed its open state.
        if (Math.abs(previousDiffFromInitial.current - diffFromInitial) > 60) {
          keyboardIsOpen.current = !keyboardIsOpen.current;
        }

        if (snapPoints && snapPoints.length > 0 && snapPointsOffset && activeSnapPointIndex) {
          const activeSnapPointHeight = snapPointsOffset[activeSnapPointIndex] || 0;
          diffFromInitial += activeSnapPointHeight;
        }
        previousDiffFromInitial.current = diffFromInitial;
        // We don't have to change the height if the input is in view, when we are here we are in the opened keyboard state so we can correctly check if the input is in view
        if (drawerHeight > visualViewportHeight || keyboardIsOpen.current) {
          const height = drawerRef.current.getBoundingClientRect().height;
          let newDrawerHeight = height;

          if (height > visualViewportHeight) {
            newDrawerHeight =
              visualViewportHeight - (isTallEnough ? offsetFromTop : WINDOW_TOP_OFFSET);
          }
          // When fixed, don't move the drawer upwards if there's space, but rather only change it's height so it's fully scrollable when the keyboard is open
          if (fixed) {
            drawerRef.current.style.height = `${height - Math.max(diffFromInitial, 0)}px`;
          } else {
            drawerRef.current.style.height = `${Math.max(newDrawerHeight, visualViewportHeight - offsetFromTop)}px`;
          }
        } else if (!isMobileFirefox()) {
          drawerRef.current.style.height = `${initialDrawerHeight.current}px`;
        }

        if (snapPoints && snapPoints.length > 0 && !keyboardIsOpen.current) {
          drawerRef.current.style.bottom = '0px';
        } else {
          // Negative bottom value would never make sense
          drawerRef.current.style.bottom = `${Math.max(diffFromInitial, 0)}px`;
        }
      }
    }

    window.visualViewport?.addEventListener('resize', onVisualViewportChange);
    return () => window.visualViewport?.removeEventListener('resize', onVisualViewportChange);
  }, [activeSnapPointIndex, snapPoints, snapPointsOffset]);

  function closeDrawer(fromWithin?: boolean) {
    cancelDrag();
    onClose?.();

    if (!fromWithin) {
      setIsOpen(false);
    }
  }

  function resetDrawer() {
    if (!drawerRef.current) return;
    const wrapper = document.querySelector('[data-vaul-drawer-wrapper]');
    const currentSwipeAmount = getTranslate(drawerRef.current, direction);

    set(drawerRef.current, {
      transform: 'translate3d(0, 0, 0)',
      transition: `transform ${TRANSITIONS.DURATION}s cubic-bezier(${TRANSITIONS.EASE.join(',')})`,
    });

    set(overlayRef.current, {
      transition: `opacity ${TRANSITIONS.DURATION}s cubic-bezier(${TRANSITIONS.EASE.join(',')})`,
      opacity: '1',
    });

    // Don't reset background if swiped upwards
    if (shouldScaleBackground && currentSwipeAmount && currentSwipeAmount > 0 && isOpen) {
      set(
        wrapper,
        {
          borderRadius: `${BORDER_RADIUS}px`,
          overflow: 'hidden',
          ...(isVertical(direction)
            ? {
                transform: `scale(${getScale()}) translate3d(0, calc(env(safe-area-inset-top) + 14px), 0)`,
                transformOrigin: 'top',
              }
            : {
                transform: `scale(${getScale()}) translate3d(calc(env(safe-area-inset-top) + 14px), 0, 0)`,
                transformOrigin: 'left',
              }),
          transitionProperty: 'transform, border-radius',
          transitionDuration: `${TRANSITIONS.DURATION}s`,
          transitionTimingFunction: `cubic-bezier(${TRANSITIONS.EASE.join(',')})`,
        },
        true
      );
    }
  }

  function cancelDrag() {
    if (!isDragging || !drawerRef.current) return;

    drawerRef.current.classList.remove(DRAG_CLASS);
    isAllowedToDrag.current = false;
    unfreezeScrollables();
    setIsDragging(false);
    dragEndTime.current = new Date();
  }

  function release(event: DragEvent | null, pointerEvent?: React.PointerEvent<HTMLDivElement>) {
    if (!isDragging || !drawerRef.current) return;

    drawerRef.current.classList.remove(DRAG_CLASS);
    isAllowedToDrag.current = false;
    unfreezeScrollables();
    setIsDragging(false);
    dragEndTime.current = new Date();

    if (dismissAttempted.current) {
      dismissAttempted.current = false;
      if (isOpen) onDismissAttempt?.();
    }

    // The press that started this "drag" may have dismissed the drawer (e.g. a
    // back button acting on pointerdown). Snapping now would overwrite the
    // dismiss transform that closeDrawer just wrote and freeze the sheet in
    // place until it unmounts.
    if (!isOpen) {
      if (pointerEvent) onReleaseProp?.(pointerEvent, false);
      return;
    }

    const swipeAmount = getTranslate(drawerRef.current, direction);

    // Drag overshoot below the lowest snap point translates the detached
    // wrapper while the drawer stays pinned (see onDrag in use-snap-points) —
    // common when a clamped 'auto' puts the lowest snap point at 0. Count the
    // wrapper's translation as movement, or the release is swallowed and the
    // sheet is left stuck at the overshoot position.
    const wrapper = drawerRef.current.closest<HTMLElement>('[data-vaul-detached-wrapper]');
    const wrapperSwipeAmount = wrapper ? getTranslate(wrapper, direction) : null;
    const hasMoved = Boolean(swipeAmount) || Boolean(wrapperSwipeAmount);

    if (!event || !shouldDrag(event.target, false) || !hasMoved || Number.isNaN(swipeAmount))
      return;

    if (dragStartTime.current === null) return;

    const timeTaken = dragEndTime.current.getTime() - dragStartTime.current.getTime();
    const distMoved = pointerStart.current - (isVertical(direction) ? event.pageY : event.pageX);
    const velocity = Math.abs(distMoved) / timeTaken;

    if (velocity > 0.05) {
      // `justReleased` is needed to prevent the drawer from focusing on an input when the drag ends, as it's not the intent most of the time.
      setJustReleased(true);

      setTimeout(() => {
        setJustReleased(false);
      }, 200);
    }

    if (snapPoints) {
      const directionMultiplier = direction === 'bottom' || direction === 'right' ? 1 : -1;
      onReleaseSnapPoints({
        draggedDistance: distMoved * directionMultiplier,
        closeDrawer,
        velocity,
        dismissible,
        dismissThreshold,
      });
      if (pointerEvent) onReleaseProp?.(pointerEvent, true);
      return;
    }

    // Moved upwards, don't do anything
    if (direction === 'bottom' || direction === 'right' ? distMoved > 0 : distMoved < 0) {
      resetDrawer();
      if (pointerEvent) onReleaseProp?.(pointerEvent, true);
      return;
    }

    if (velocity > VELOCITY_THRESHOLD) {
      closeDrawer();
      if (pointerEvent) onReleaseProp?.(pointerEvent, false);
      return;
    }

    const visibleDrawerHeight = Math.min(
      drawerRef.current.getBoundingClientRect().height ?? 0,
      window.innerHeight
    );
    const visibleDrawerWidth = Math.min(
      drawerRef.current.getBoundingClientRect().width ?? 0,
      window.innerWidth
    );

    const isHorizontalSwipe = direction === 'left' || direction === 'right';
    if (
      Math.abs(swipeAmount ?? 0) >=
      (isHorizontalSwipe ? visibleDrawerWidth : visibleDrawerHeight) * closeThreshold
    ) {
      closeDrawer();
      if (pointerEvent) onReleaseProp?.(pointerEvent, false);
      return;
    }

    if (pointerEvent) onReleaseProp?.(pointerEvent, true);
    resetDrawer();
  }

  React.useEffect(() => {
    // Trigger enter animation without using CSS animation
    if (isOpen) {
      set(document.documentElement, {
        scrollBehavior: 'auto',
      });

      openTime.current = new Date();
    }

    return () => {
      reset(document.documentElement, 'scrollBehavior');
    };
  }, [isOpen]);

  function onNestedOpenChange(o: boolean) {
    const scale = o ? (window.innerWidth - NESTED_DISPLACEMENT) / window.innerWidth : 1;

    const initialTranslate = o ? -NESTED_DISPLACEMENT : 0;

    if (nestedOpenChangeTimer.current) {
      window.clearTimeout(nestedOpenChangeTimer.current);
    }

    set(drawerRef.current, {
      transition: `transform ${TRANSITIONS.DURATION}s cubic-bezier(${TRANSITIONS.EASE.join(',')})`,
      transform: isVertical(direction)
        ? `scale(${scale}) translate3d(0, ${initialTranslate}px, 0)`
        : `scale(${scale}) translate3d(${initialTranslate}px, 0, 0)`,
    });

    if (!o && drawerRef.current) {
      nestedOpenChangeTimer.current = setTimeout(() => {
        const translateValue = getTranslate(drawerRef.current as HTMLElement, direction);
        set(drawerRef.current, {
          transition: 'none',
          transform: isVertical(direction)
            ? `translate3d(0, ${translateValue}px, 0)`
            : `translate3d(${translateValue}px, 0, 0)`,
        });
      }, 500);
    }
  }

  function onNestedDrag(_event: React.PointerEvent<HTMLDivElement>, percentageDragged: number) {
    if (percentageDragged < 0) return;

    const initialScale = (window.innerWidth - NESTED_DISPLACEMENT) / window.innerWidth;
    const newScale = initialScale + percentageDragged * (1 - initialScale);
    const newTranslate = -NESTED_DISPLACEMENT + percentageDragged * NESTED_DISPLACEMENT;

    set(drawerRef.current, {
      transform: isVertical(direction)
        ? `scale(${newScale}) translate3d(0, ${newTranslate}px, 0)`
        : `scale(${newScale}) translate3d(${newTranslate}px, 0, 0)`,
      transition: 'none',
    });
  }

  function onNestedRelease(_event: React.PointerEvent<HTMLDivElement>, o: boolean) {
    const dim = isVertical(direction) ? window.innerHeight : window.innerWidth;
    const scale = o ? (dim - NESTED_DISPLACEMENT) / dim : 1;
    const translate = o ? -NESTED_DISPLACEMENT : 0;

    if (o) {
      set(drawerRef.current, {
        transition: `transform ${TRANSITIONS.DURATION}s cubic-bezier(${TRANSITIONS.EASE.join(',')})`,
        transform: isVertical(direction)
          ? `scale(${scale}) translate3d(0, ${translate}px, 0)`
          : `scale(${scale}) translate3d(${translate}px, 0, 0)`,
      });
    }
  }

  return (
    <DialogPrimitive.Root
      defaultOpen={defaultOpen}
      onOpenChange={(open) => {
        if (!dismissible && !open) return;
        if (open) {
          setHasBeenOpened(true);
        } else {
          closeDrawer(true);
        }

        setIsOpen(open);
      }}
      open={isOpen}
      // Always non-modal at the Radix level — Radix's modal mode locks
      // body.style.pointerEvents and its restore on layer unmount is buggy
      // (see git history). Vaul's own overlay handles click-trapping; the
      // overlay sets pointer-events: none below fadeFromIndex so clicks
      // pass through to the page (matches native dimmedDetentIndex). Vaul's
      // own `modal` prop still drives overlay rendering and click-outside
      // behavior below.
      modal={false}
    >
      <DrawerContext.Provider
        value={{
          activeSnapPoint,
          snapPoints,
          setActiveSnapPoint,
          drawerRef,
          overlayRef,
          onOpenChange,
          onPress,
          onRelease: (event) => release(event, event ?? undefined),
          onDrag: (event) => drag(event, event),
          onTouchDrag: (event, pointerEvent) => drag(event, pointerEvent),
          onTouchRelease: (event, pointerEvent) => release(event, pointerEvent),
          dismissible,
          onDismissAttempt,
          shouldAnimate,
          initialAnimated,
          hasPresented,
          handleOnly,
          isOpen,
          isDragging,
          shouldFade,
          closeDrawer,
          onNestedDrag,
          onNestedOpenChange,
          onNestedRelease,
          keyboardIsOpen,
          modal,
          snapPointsOffset,
          activeSnapPointIndex,
          fadeFromIndex,
          direction,
          shouldScaleBackground,
          setBackgroundColorOnScale,
          noBodyStyles,
          container,
          autoFocus,
          onPositionChangeRef,
          setContentHeight,
          detached,
          detachedOffset: detached ? detachedOffset : 0,
          detachedRadius: detached ? detachedRadius : 0,
          detachedWrapperStyle,
          keyboardViewport,
        }}
      >
        {children}
      </DrawerContext.Provider>
    </DialogPrimitive.Root>
  );
}

export const Overlay = React.forwardRef<
  HTMLDivElement,
  React.ComponentPropsWithoutRef<typeof DialogPrimitive.Overlay>
>(({ style, ...rest }, ref) => {
  const {
    overlayRef,
    snapPoints,
    onRelease,
    shouldFade,
    isOpen,
    modal,
    shouldAnimate,
    activeSnapPointIndex,
    fadeFromIndex,
  } = useDrawerContext();
  const composedRef = useComposedRefs(ref, overlayRef);
  const hasSnapPoints = snapPoints && snapPoints.length > 0;
  const [delayedSnapPoints, setDelayedSnapPoints] = React.useState(false);
  const onMouseUp = React.useCallback(
    (event: React.PointerEvent<HTMLDivElement>) => onRelease(event),
    [onRelease]
  );

  React.useEffect(() => {
    if (hasSnapPoints) {
      window.requestAnimationFrame(() => {
        setDelayedSnapPoints(true);
      });
    }
  }, []);

  // Overlay is the component that is locking scroll, removing it will unlock the scroll without having to dig into Radix's Dialog library
  if (!modal) {
    return null;
  }

  // When the active snap is below fadeFromIndex, the overlay is fully
  // transparent (CSS opacity: 0). Radix's DialogOverlayImpl sets inline
  // `pointer-events: auto` which would still catch clicks on the invisible
  // layer — drive this via React so it stays correct even before
  // `snapToPoint` runs (Presence defers the drawer/overlay mount, leaving
  // refs null on the first open effect pass).
  const isBelowFade =
    hasSnapPoints &&
    fadeFromIndex !== undefined &&
    typeof activeSnapPointIndex === 'number' &&
    activeSnapPointIndex < fadeFromIndex;

  // Render our own overlay element instead of `DialogPrimitive.Overlay`:
  // Radix's Overlay returns null when the Dialog is non-modal, and we run
  // Radix as `modal={false}` to keep it from locking body pointer-events.
  // `Presence` keeps the node mounted through the closing animation
  // (`fadeOut`) before unmounting.
  return (
    <Presence present={isOpen}>
      <div
        onMouseUp={onMouseUp}
        ref={composedRef}
        data-state={isOpen ? 'open' : 'closed'}
        data-vaul-overlay=""
        data-vaul-snap-points={isOpen && hasSnapPoints ? 'true' : 'false'}
        data-vaul-delayed-snap-points={delayedSnapPoints ? 'true' : 'false'}
        data-vaul-snap-points-overlay={isOpen && shouldFade ? 'true' : 'false'}
        data-vaul-animate={shouldAnimate?.current ? 'true' : 'false'}
        {...rest}
        style={overlayStyle(style, !!isBelowFade)}
      />
    </Presence>
  );
});

Overlay.displayName = 'Drawer.Overlay';

const overlayStyle = (
  style: React.CSSProperties | undefined,
  isBelowFade: boolean
): React.CSSProperties => ({
  ...style,
  pointerEvents: isBelowFade ? 'none' : 'auto',
});

export type ContentProps = React.ComponentPropsWithoutRef<typeof DialogPrimitive.Content> & {
  /**
   * Extra nodes rendered inside the detached clip wrapper as siblings of the
   * drawer. Use for floating elements (e.g. a footer) that should slide with
   * the wrapper on dismiss and drag-overshoot instead of staying pinned.
   */
  detachedSiblings?: React.ReactNode;
};

export const Content = React.forwardRef<HTMLDivElement, ContentProps>(
  (
    {
      onPointerDownOutside,
      onEscapeKeyDown,
      style,
      onOpenAutoFocus,
      children,
      detachedSiblings,
      ...rest
    },
    ref
  ) => {
    const {
      drawerRef,
      onPress,
      onRelease,
      onDrag,
      onTouchDrag,
      onTouchRelease,
      keyboardIsOpen,
      snapPointsOffset,
      activeSnapPointIndex,
      fadeFromIndex,
      modal,
      isOpen,
      isDragging,
      direction,
      snapPoints,
      setActiveSnapPoint,
      dismissible,
      onDismissAttempt,
      container,
      handleOnly,
      shouldAnimate,
      initialAnimated,
      hasPresented,
      autoFocus,
      onPositionChangeRef,
      setContentHeight,
      detached,
      detachedOffset,
      detachedRadius,
      detachedWrapperStyle: detachedWrapperStyleProp,
      keyboardViewport,
    } = useDrawerContext();
    // Always measure the inner wrapper's natural height. The drawer itself may
    // be styled to a fixed viewport height, so we measure an inner wrapper
    // instead. Ref callback starts the observer as soon as the node mounts
    // (Radix Presence defers the portal mount past useEffect). The measurement
    // drives the 'auto' snap point and is also exposed via
    // `onContentHeightChange` for callers that size the surrounding card.
    const autoRoRef = React.useRef<ResizeObserver | null>(null);
    const setAutoSizeNode = React.useCallback(
      (node: HTMLDivElement | null) => {
        autoRoRef.current?.disconnect();
        if (!node) {
          autoRoRef.current = null;
          return;
        }
        const measure = () => setContentHeight(node.offsetHeight);
        measure();
        const ro = new ResizeObserver(measure);
        ro.observe(node);
        autoRoRef.current = ro;
      },
      [setContentHeight]
    );

    const isBelowFade =
      snapPoints !== undefined &&
      snapPoints !== null &&
      fadeFromIndex !== undefined &&
      typeof activeSnapPointIndex === 'number' &&
      activeSnapPointIndex < fadeFromIndex;
    // Needed to use transition instead of animations
    const [delayedSnapPoints, setDelayedSnapPoints] = React.useState(false);
    const composedRef = useComposedRefs(ref, drawerRef);
    const pointerStartRef = React.useRef<{ x: number; y: number } | null>(null);
    const lastKnownPointerEventRef = React.useRef<React.PointerEvent<HTMLDivElement> | null>(null);
    const continuingCanceledTouchRef = React.useRef(false);
    const wasBeyondThePointRef = React.useRef(false);
    const hasSnapPoints = snapPoints && snapPoints.length > 0;
    useScaleBackground();

    const isDeltaInDirection = (
      delta: { x: number; y: number },
      dir: DrawerDirection,
      threshold = 0
    ) => {
      if (wasBeyondThePointRef.current) return true;

      const deltaY = Math.abs(delta.y);
      const deltaX = Math.abs(delta.x);
      const isDeltaX = deltaX > deltaY;
      const dFactor = ['bottom', 'right'].includes(dir) ? 1 : -1;

      if (dir === 'left' || dir === 'right') {
        const isReverseDirection = delta.x * dFactor < 0;
        if (!isReverseDirection && deltaX >= 0 && deltaX <= threshold) {
          return isDeltaX;
        }
      } else {
        const isReverseDirection = delta.y * dFactor < 0;
        if (!isReverseDirection && deltaY >= 0 && deltaY <= threshold) {
          return !isDeltaX;
        }
      }

      wasBeyondThePointRef.current = true;
      return true;
    };

    React.useEffect(() => {
      if (hasSnapPoints) {
        window.requestAnimationFrame(() => {
          setDelayedSnapPoints(true);
        });
      }
    }, []);

    // Event-driven position tracking. We only tick RAF while the drawer is
    // actually moving (drag / CSS transition / CSS animation). When it's idle at
    // a snap, no frames run at all.
    const positionTrackingRef = React.useRef<{
      rafId: number | null;
      movingCount: number;
      lastPosition: number;
      start: () => void;
      stop: () => void;
    } | null>(null);

    React.useEffect(() => {
      const drawer = drawerRef.current;
      if (!drawer) return;

      const state = {
        rafId: null as number | null,
        movingCount: 0,
        lastPosition: Number.NaN,
        start: () => {},
        stop: () => {},
      };

      const emit = () => {
        const cb = onPositionChangeRef.current;
        if (!cb) return;
        const position = drawer.getBoundingClientRect().top;
        if (position !== state.lastPosition) {
          state.lastPosition = position;
          cb(position);
        }
      };

      const tick = () => {
        emit();
        state.rafId = state.movingCount > 0 ? window.requestAnimationFrame(tick) : null;
      };

      state.start = () => {
        state.movingCount += 1;
        if (state.rafId === null) {
          state.rafId = window.requestAnimationFrame(tick);
        }
      };

      state.stop = () => {
        state.movingCount = Math.max(0, state.movingCount - 1);
        // RAF loop will exit on its next tick; emit the settled position now.
        if (state.movingCount === 0) emit();
      };

      const wrapper = drawer.closest<HTMLElement>('[data-vaul-detached-wrapper]');

      // Listen on the wrapper too: drag-overshoot snap-back animates the wrapper
      // alone when the drawer's target is unchanged (e.g. snapping back to the
      // same detent). Without this, position goes stale mid-animation because
      // the drawer's `transitionrun` never fires.
      const onTransitionRun = (e: TransitionEvent) => {
        if (
          (e.target === drawer || e.target === wrapper) &&
          (e.propertyName === 'transform' || e.propertyName === '--snap-point-height')
        )
          state.start();
      };
      const onTransitionDone = (e: TransitionEvent) => {
        if (
          (e.target === drawer || e.target === wrapper) &&
          (e.propertyName === 'transform' || e.propertyName === '--snap-point-height')
        )
          state.stop();
      };
      const onAnimationStart = (e: AnimationEvent) => {
        if (e.target === drawer || e.target === wrapper) state.start();
      };
      const onAnimationDone = (e: AnimationEvent) => {
        if (e.target === drawer || e.target === wrapper) state.stop();
      };

      drawer.addEventListener('transitionrun', onTransitionRun);
      drawer.addEventListener('transitionend', onTransitionDone);
      drawer.addEventListener('transitioncancel', onTransitionDone);
      drawer.addEventListener('animationstart', onAnimationStart);
      drawer.addEventListener('animationend', onAnimationDone);
      drawer.addEventListener('animationcancel', onAnimationDone);
      wrapper?.addEventListener('transitionrun', onTransitionRun);
      wrapper?.addEventListener('transitionend', onTransitionDone);
      wrapper?.addEventListener('transitioncancel', onTransitionDone);

      positionTrackingRef.current = state;
      emit();

      return () => {
        drawer.removeEventListener('transitionrun', onTransitionRun);
        drawer.removeEventListener('transitionend', onTransitionDone);
        drawer.removeEventListener('transitioncancel', onTransitionDone);
        drawer.removeEventListener('animationstart', onAnimationStart);
        drawer.removeEventListener('animationend', onAnimationDone);
        drawer.removeEventListener('animationcancel', onAnimationDone);
        wrapper?.removeEventListener('transitionrun', onTransitionRun);
        wrapper?.removeEventListener('transitionend', onTransitionDone);
        wrapper?.removeEventListener('transitioncancel', onTransitionDone);
        if (state.rafId !== null) window.cancelAnimationFrame(state.rafId);
        positionTrackingRef.current = null;
      };
    }, []);

    React.useEffect(() => {
      const state = positionTrackingRef.current;
      if (!state) return;
      if (isDragging) state.start();
      else state.stop();
    }, [isDragging]);

    function handleOnPointerUp(event: React.PointerEvent<HTMLDivElement> | null) {
      pointerStartRef.current = null;
      wasBeyondThePointRef.current = false;
      onRelease(event);
    }

    // The drawer always sits inside a fixed clip wrapper. `contain: paint`
    // establishes the wrapper as the containing block so the drawer's own
    // `position: fixed` is constrained here, and `overflow: hidden` keeps any
    // overshoot out of the viewport. When `detached` the wrapper also floats
    // with a bottom gap and rounded bottom corners; otherwise it sits flush.
    // Transform/transition are managed imperatively (via drag overshoot and the
    // dismiss effect) so React doesn't skip DOM writes for values it thinks it
    // already owns. Above a soft keyboard the wrapper fits the visual viewport,
    // which the full-height layout viewport extends behind.
    const wrapperStyle = React.useMemo<React.CSSProperties>(
      () => ({
        position: 'fixed',
        left: 0,
        right: 0,
        ...(keyboardViewport
          ? {
              top: keyboardViewport.top,
              height: Math.max(0, keyboardViewport.height - (detached ? detachedOffset : 0)),
            }
          : { top: 0, bottom: detached ? detachedOffset : 0 }),
        overflow: 'hidden',
        contain: 'paint',
        pointerEvents: 'none',
        borderBottomLeftRadius: detached ? detachedRadius : 0,
        borderBottomRightRadius: detached ? detachedRadius : 0,
        ...detachedWrapperStyleProp,
      }),
      [detached, detachedOffset, detachedRadius, detachedWrapperStyleProp, keyboardViewport]
    );

    // Translate the wrapper off-screen on dismiss so the whole card slides out
    // as one. The reset-then-target pattern on open forces the browser to
    // record a starting value so the transition actually animates.
    // Start at `false` so a mount with `isOpen=true` (autopresent via
    // `initialDetentIndex`) is detected as a false→true transition and runs
    // the slide-up animation instead of snapping straight to rest.
    const wasOpenRef = React.useRef(false);
    React.useEffect(() => {
      if (!drawerRef.current) {
        wasOpenRef.current = isOpen;
        return;
      }
      const wrapper = drawerRef.current.closest<HTMLElement>('[data-vaul-detached-wrapper]');
      if (wrapper) {
        const transition = `transform ${TRANSITIONS.DURATION}s cubic-bezier(${TRANSITIONS.EASE.join(',')})`;
        const viewportH = typeof window !== 'undefined' ? window.innerHeight : 0;
        if (!isOpen && wasOpenRef.current) {
          wrapper.style.transition = transition;
          wrapper.style.transform = `translate3d(0, ${viewportH}px, 0)`;
        } else if (isOpen && !wasOpenRef.current) {
          wrapper.style.transition = 'none';
          if (hasPresented.current || initialAnimated) {
            wrapper.style.transform = `translate3d(0, ${viewportH}px, 0)`;
            // eslint-disable-next-line no-void
            void wrapper.offsetHeight;
            wrapper.style.transition = transition;
          }
          wrapper.style.transform = 'translate3d(0, 0, 0)';
          hasPresented.current = true;
        }
      }
      wasOpenRef.current = isOpen;
    }, [isOpen, detached, drawerRef, initialAnimated, hasPresented]);

    // Subsequent snap writes belong to useSnapPoints. A React style update on
    // release would overwrite the live drag value before its transition starts.
    const initialSnapPointOffset = React.useRef(snapPointsOffset?.[activeSnapPointIndex ?? 0] ?? 0);
    const contentNode = (
      <DialogPrimitive.Content
        data-vaul-drawer-direction={direction}
        data-vaul-drawer=""
        data-vaul-detached={detached ? 'true' : 'false'}
        data-vaul-delayed-snap-points={delayedSnapPoints ? 'true' : 'false'}
        data-vaul-snap-points={isOpen && hasSnapPoints ? 'true' : 'false'}
        data-vaul-custom-container={container ? 'true' : 'false'}
        data-vaul-animate={shouldAnimate?.current ? 'true' : 'false'}
        {...rest}
        ref={composedRef}
        style={
          snapPointsOffset && snapPointsOffset.length > 0
            ? ({
                '--snap-point-height': `${initialSnapPointOffset.current}px`,
                'transform': getSnapPointTransform(direction),
                ...style,
                'pointerEvents': 'auto',
              } as React.CSSProperties)
            : ({ ...style, pointerEvents: 'auto' } as React.CSSProperties)
        }
        onPointerDown={(event) => {
          if (handleOnly) return;
          rest.onPointerDown?.(event);
          continuingCanceledTouchRef.current = false;
          pointerStartRef.current = { x: event.pageX, y: event.pageY };
          onPress(event);
        }}
        onOpenAutoFocus={(e) => {
          onOpenAutoFocus?.(e);

          if (!autoFocus) {
            e.preventDefault();
          }
        }}
        onPointerDownOutside={(e) => {
          onPointerDownOutside?.(e);

          if (!modal || e.defaultPrevented || isBelowFade) {
            e.preventDefault();
            return;
          }

          // Non-dismissible + dimmed: collapse to the highest non-dimmed
          // snap point instead of silently swallowing the dismiss attempt.
          // Mirrors the native Android dim-tap behavior.
          if (
            !dismissible &&
            hasSnapPoints &&
            fadeFromIndex !== undefined &&
            fadeFromIndex > 0 &&
            typeof activeSnapPointIndex === 'number' &&
            activeSnapPointIndex >= fadeFromIndex
          ) {
            e.preventDefault();
            setActiveSnapPoint(snapPoints![fadeFromIndex - 1]!);
            return;
          }

          if (keyboardIsOpen.current) {
            keyboardIsOpen.current = false;
          }
        }}
        onEscapeKeyDown={(e) => {
          onEscapeKeyDown?.(e);
          if (e.defaultPrevented) return;

          // Non-dismissible: collapse to the first snap point (if above it)
          // instead of silently swallowing the dismiss attempt. Mirrors the
          // native Android back-press behavior.
          if (!dismissible) {
            e.preventDefault();
            if (
              hasSnapPoints &&
              typeof activeSnapPointIndex === 'number' &&
              activeSnapPointIndex > 0
            ) {
              setActiveSnapPoint(snapPoints![0]!);
            } else {
              onDismissAttempt?.();
            }
          }
        }}
        onFocusOutside={(e) => {
          // Never auto-dismiss the sheet on focus shifts. Without Radix's
          // FocusScope trap (we run modal={false}), this fires whenever
          // focus naturally leaves the drawer — e.g. React Navigation's
          // web driver hides the previous screen via display:none, which
          // moves focus off the trigger and dismisses the sheet.
          e.preventDefault();
        }}
        onPointerMove={(event) => {
          lastKnownPointerEventRef.current = event;
          if (handleOnly) return;
          rest.onPointerMove?.(event);
          if (!pointerStartRef.current) return;
          const yPosition = event.pageY - pointerStartRef.current.y;
          const xPosition = event.pageX - pointerStartRef.current.x;

          const swipeStartThreshold = event.pointerType === 'touch' ? 10 : 2;
          const delta = { x: xPosition, y: yPosition };

          const isAllowedToSwipe = isDeltaInDirection(delta, direction, swipeStartThreshold);
          if (isAllowedToSwipe) onDrag(event);
          else if (
            Math.abs(xPosition) > swipeStartThreshold ||
            Math.abs(yPosition) > swipeStartThreshold
          ) {
            pointerStartRef.current = null;
          }
        }}
        onPointerUp={(event) => {
          rest.onPointerUp?.(event);
          continuingCanceledTouchRef.current = false;
          pointerStartRef.current = null;
          wasBeyondThePointRef.current = false;
          onRelease(event);
        }}
        onPointerCancel={(event) => {
          rest.onPointerCancel?.(event);
          if (
            event.pointerType === 'touch' &&
            snapPoints &&
            activeSnapPointIndex === snapPoints.length - 1
          ) {
            continuingCanceledTouchRef.current = true;
            return;
          }
          handleOnPointerUp(null);
        }}
        onPointerOut={(event) => {
          rest.onPointerOut?.(event);
          if (continuingCanceledTouchRef.current) return;
          handleOnPointerUp(lastKnownPointerEventRef.current);
        }}
        onTouchMove={(event) => {
          rest.onTouchMove?.(event);
          if (!continuingCanceledTouchRef.current) return;
          const touch = event.touches[0];
          if (!touch) return;
          onTouchDrag(
            {
              target: event.target,
              pageX: touch.pageX,
              pageY: touch.pageY,
              pointerType: 'touch',
            },
            lastKnownPointerEventRef.current ?? undefined
          );
        }}
        onTouchEnd={(event) => {
          rest.onTouchEnd?.(event);
          if (!continuingCanceledTouchRef.current) return;
          continuingCanceledTouchRef.current = false;
          pointerStartRef.current = null;
          wasBeyondThePointRef.current = false;
          const touch = event.changedTouches[0];
          onTouchRelease(
            touch
              ? {
                  target: event.target,
                  pageX: touch.pageX,
                  pageY: touch.pageY,
                  pointerType: 'touch',
                }
              : null,
            lastKnownPointerEventRef.current ?? undefined
          );
        }}
        onTouchCancel={(event) => {
          rest.onTouchCancel?.(event);
          if (!continuingCanceledTouchRef.current) return;
          continuingCanceledTouchRef.current = false;
          handleOnPointerUp(null);
        }}
        onContextMenu={(event) => {
          rest.onContextMenu?.(event);
          if (lastKnownPointerEventRef.current) {
            handleOnPointerUp(lastKnownPointerEventRef.current);
          }
        }}
      >
        <div ref={setAutoSizeNode} data-vaul-auto-size-wrapper="" style={autoSizeWrapperStyle}>
          {children}
        </div>
      </DialogPrimitive.Content>
    );

    return (
      <div data-vaul-detached-wrapper="" style={wrapperStyle}>
        {contentNode}
        {detachedSiblings}
      </div>
    );
  }
);

Content.displayName = 'Drawer.Content';

// `flow-root` establishes a new block formatting context so the first child's
// margin-top (e.g. a grabber) stays inside the wrapper instead of collapsing
// out — otherwise `offsetHeight` under-reports and the drawer positions the
// wrapper below where the content actually ends.
const autoSizeWrapperStyle: React.CSSProperties = { display: 'flow-root' };

export type HandleProps = React.ComponentPropsWithoutRef<'div'> & {
  preventCycle?: boolean;
};

const LONG_HANDLE_PRESS_TIMEOUT = 250;
const DOUBLE_TAP_TIMEOUT = 120;

export const Handle = React.forwardRef<HTMLDivElement, HandleProps>(
  ({ preventCycle = false, children, ...rest }, ref) => {
    const {
      closeDrawer,
      isDragging,
      snapPoints,
      activeSnapPoint,
      setActiveSnapPoint,
      dismissible,
      onDismissAttempt,
      handleOnly,
      isOpen,
      onPress,
      onDrag,
    } = useDrawerContext();

    const closeTimeoutIdRef = React.useRef<number | null>(null);
    const shouldCancelInteractionRef = React.useRef(false);

    function handleStartCycle() {
      // Stop if this is the second click of a double click
      if (shouldCancelInteractionRef.current) {
        handleCancelInteraction();
        return;
      }
      window.setTimeout(() => {
        handleCycleSnapPoints();
      }, DOUBLE_TAP_TIMEOUT);
    }

    function handleCycleSnapPoints() {
      // Prevent accidental taps while resizing drawer
      if (isDragging || preventCycle || shouldCancelInteractionRef.current) {
        handleCancelInteraction();
        return;
      }
      // Make sure to clear the timeout id if the user releases the handle before the cancel timeout
      handleCancelInteraction();

      if (!snapPoints || snapPoints.length === 0) {
        if (!dismissible) {
          closeDrawer();
        }
        return;
      }

      const isLastSnapPoint = activeSnapPoint === snapPoints[snapPoints.length - 1];

      if (isLastSnapPoint && dismissible) {
        closeDrawer();
        return;
      }

      // Mirrors native: a single-detent sheet's handle tap is a dismiss.
      if (isLastSnapPoint && snapPoints.length === 1) {
        onDismissAttempt?.();
        return;
      }

      const currentSnapIndex = snapPoints.findIndex((point) => point === activeSnapPoint);
      if (currentSnapIndex === -1) return; // activeSnapPoint not found in snapPoints
      const nextSnapPoint = snapPoints[currentSnapIndex + 1];
      if (nextSnapPoint === undefined) return;
      setActiveSnapPoint(nextSnapPoint);
    }

    function handleStartInteraction() {
      closeTimeoutIdRef.current = window.setTimeout(() => {
        // Cancel click interaction on a long press
        shouldCancelInteractionRef.current = true;
      }, LONG_HANDLE_PRESS_TIMEOUT);
    }

    function handleCancelInteraction() {
      if (closeTimeoutIdRef.current) {
        window.clearTimeout(closeTimeoutIdRef.current);
      }
      shouldCancelInteractionRef.current = false;
    }

    return (
      <div
        onClick={handleStartCycle}
        onPointerCancel={handleCancelInteraction}
        onPointerDown={(e) => {
          if (handleOnly) onPress(e);
          handleStartInteraction();
        }}
        onPointerMove={(e) => {
          if (handleOnly) onDrag(e);
        }}
        // onPointerUp is already handled by the content component
        ref={ref}
        data-vaul-drawer-visible={isOpen ? 'true' : 'false'}
        data-vaul-handle=""
        aria-hidden="true"
        {...rest}
      >
        {/* Expand handle's hit area beyond what's visible to ensure a 44x44 tap target for touch devices */}
        <span data-vaul-handle-hitarea="" aria-hidden="true">
          {children}
        </span>
      </div>
    );
  }
);

Handle.displayName = 'Drawer.Handle';

export function NestedRoot({ onDrag, onOpenChange, open: nestedIsOpen, ...rest }: DialogProps) {
  const { onNestedDrag, onNestedOpenChange, onNestedRelease } = useDrawerContext();

  if (!onNestedDrag) {
    throw new Error('Drawer.NestedRoot must be placed in another drawer');
  }

  return (
    <Root
      nested
      open={nestedIsOpen}
      onClose={() => {
        onNestedOpenChange(false);
      }}
      onDrag={(e, p) => {
        onNestedDrag(e, p);
        onDrag?.(e, p);
      }}
      onOpenChange={(o) => {
        if (o) {
          onNestedOpenChange(o);
        }
        onOpenChange?.(o);
      }}
      onRelease={onNestedRelease}
      {...rest}
    />
  );
}

type PortalProps = React.ComponentPropsWithoutRef<typeof DialogPrimitive.Portal>;

export function Portal(props: PortalProps) {
  const context = useDrawerContext();
  const { container = context.container, ...portalProps } = props;

  return <DialogPrimitive.Portal container={container} {...portalProps} />;
}

export const Drawer = {
  Root,
  NestedRoot,
  Content,
  Overlay,
  Trigger: DialogPrimitive.Trigger,
  Portal,
  Handle,
  Close: DialogPrimitive.Close,
  Title: DialogPrimitive.Title,
  Description: DialogPrimitive.Description,
};
