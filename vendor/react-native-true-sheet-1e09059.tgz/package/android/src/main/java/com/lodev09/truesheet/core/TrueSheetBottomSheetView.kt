package com.lodev09.truesheet.core

import android.annotation.SuppressLint
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Rect
import android.graphics.drawable.ShapeDrawable
import android.graphics.drawable.shapes.RoundRectShape
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.view.ViewCompat
import com.facebook.react.uimanager.PixelUtil.dpToPx
import com.facebook.react.uimanager.ThemedReactContext
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.lodev09.truesheet.TrueSheetPlacement
import com.lodev09.truesheet.utils.ScreenUtils
import com.lodev09.truesheet.utils.isDarkMode

interface TrueSheetBottomSheetViewDelegate {
  val isTopmostSheet: Boolean
  val sheetCornerRadius: Float
  val sheetElevation: Float
  val sheetBackgroundColor: Int?
  val maxContentWidth: Int?
  val placement: TrueSheetPlacement
  val placementOffset: Int
  val grabber: Boolean
  val grabberOptions: GrabberOptions?
  val accessibilityOptions: AccessibilityOptions?
  val draggable: Boolean
  fun bottomSheetViewDidTapGrabber()
  fun bottomSheetViewDidAccessibilityIncrement()
  fun bottomSheetViewDidAccessibilityDecrement()
}

/**
 * The bottom sheet view that holds the content.
 * This view has BottomSheetBehavior attached via CoordinatorLayout.LayoutParams.
 *
 * Touch dispatching to React Native is handled by TrueSheetViewController,
 * which is the actual RootView containing the React content.
 */
@SuppressLint("ViewConstructor")
class TrueSheetBottomSheetView(private val reactContext: ThemedReactContext) : FrameLayout(reactContext) {

  companion object {
    private const val GRABBER_TAG = "TrueSheetGrabber"
    private const val DEFAULT_CORNER_RADIUS = 16f // dp
    private const val DEFAULT_MAX_WIDTH = 640 // dp
    private const val DEFAULT_ELEVATION = 4f // dp

    // M3 baseline surfaceContainerLow
    private val COLOR_SURFACE_CONTAINER_LOW_LIGHT = Color.parseColor("#F7F2FA")
    private val COLOR_SURFACE_CONTAINER_LOW_DARK = Color.parseColor("#1D1B20")
  }

  // =============================================================================
  // MARK: - Properties
  // =============================================================================

  var delegate: TrueSheetBottomSheetViewDelegate? = null

  // Behavior reference (set after adding to CoordinatorLayout)
  @Suppress("UNCHECKED_CAST")
  val behavior: TrueSheetBottomSheetBehavior<TrueSheetBottomSheetView>?
    get() = (layoutParams as? CoordinatorLayout.LayoutParams)
      ?.behavior as? TrueSheetBottomSheetBehavior<TrueSheetBottomSheetView>

  // =============================================================================
  // MARK: - Initialization
  // =============================================================================

  init {
    // Allow content to extend beyond bounds (for footer positioning)
    clipChildren = false
    clipToPadding = false
  }

  // =============================================================================
  // MARK: - Layout
  // =============================================================================

  private fun resolveAnchor(): Pair<Int, Int> {
    val placement = if (ScreenUtils.isPortraitPhone(reactContext)) null else delegate?.placement
    val gravity = when (placement) {
      TrueSheetPlacement.LEADING -> Gravity.START
      TrueSheetPlacement.TRAILING -> Gravity.END
      else -> Gravity.CENTER_HORIZONTAL
    } or Gravity.BOTTOM
    val margin = if (placement == TrueSheetPlacement.LEADING ||
      placement == TrueSheetPlacement.TRAILING
    ) {
      delegate?.placementOffset ?: 0
    } else {
      0
    }
    return Pair(gravity, margin)
  }

  /**
   * Creates layout params with BottomSheetBehavior attached.
   */
  fun createLayoutParams(): CoordinatorLayout.LayoutParams {
    val applyMaxWidth = delegate?.maxContentWidth != null && !ScreenUtils.isPortraitPhone(reactContext)
    val effectiveMaxWidth = if (applyMaxWidth) delegate!!.maxContentWidth!! else DEFAULT_MAX_WIDTH.dpToPx().toInt()
    val behavior = TrueSheetBottomSheetBehavior<TrueSheetBottomSheetView>().apply {
      isHideable = true
      maxWidth = effectiveMaxWidth
    }

    val (gravity, margin) = resolveAnchor()

    return CoordinatorLayout.LayoutParams(
      CoordinatorLayout.LayoutParams.MATCH_PARENT,
      CoordinatorLayout.LayoutParams.MATCH_PARENT
    ).apply {
      this.behavior = behavior
      this.gravity = gravity
      this.marginStart = margin
      this.marginEnd = margin
    }
  }

  fun updateGravity() {
    val params = layoutParams as? CoordinatorLayout.LayoutParams ?: return
    val (gravity, margin) = resolveAnchor()

    if (params.gravity == gravity && params.marginStart == margin) return

    params.gravity = gravity
    params.marginStart = margin
    params.marginEnd = margin
    layoutParams = params
  }

  // =============================================================================
  // MARK: - Background & Styling
  // =============================================================================

  fun setupBackground() {
    val radius = delegate?.sheetCornerRadius ?: DEFAULT_CORNER_RADIUS.dpToPx()
    val effectiveRadius = if (radius < 0) DEFAULT_CORNER_RADIUS.dpToPx() else radius

    val outerRadii = floatArrayOf(
      effectiveRadius,
      effectiveRadius, // top-left
      effectiveRadius,
      effectiveRadius, // top-right
      0f,
      0f, // bottom-right
      0f,
      0f // bottom-left
    )

    val color = delegate?.sheetBackgroundColor ?: getDefaultBackgroundColor()

    background = ShapeDrawable(RoundRectShape(outerRadii, null, null)).apply {
      paint.color = color
    }

    outlineProvider = object : ViewOutlineProvider() {
      override fun getOutline(view: View, outline: Outline) {
        outline.setRoundRect(0, 0, view.width, view.height, effectiveRadius)
      }
    }
    clipToOutline = true
  }

  fun updateBackgroundColor(color: Int) {
    (background as? ShapeDrawable)?.let {
      it.paint.color = color
      it.invalidateSelf()
    }
  }

  fun getDefaultBackgroundColor(): Int =
    if (reactContext.isDarkMode) COLOR_SURFACE_CONTAINER_LOW_DARK else COLOR_SURFACE_CONTAINER_LOW_LIGHT

  fun setupElevation() {
    val value = delegate?.sheetElevation ?: DEFAULT_ELEVATION
    val effectiveElevation = if (value < 0) DEFAULT_ELEVATION else value
    elevation = effectiveElevation.dpToPx()
  }

  // =============================================================================
  // MARK: - Grabber
  // =============================================================================

  fun setupGrabber() {
    findViewWithTag<View>(GRABBER_TAG)?.let { removeView(it) }

    // Content view is the controller, added before the grabber (delegate is the controller)
    val contentView = delegate as? View

    val isEnabled = delegate?.grabber ?: true
    val isDraggable = delegate?.draggable ?: true
    if (!isEnabled || !isDraggable) {
      contentView?.accessibilityTraversalAfter = View.NO_ID
      return
    }

    val grabberView = TrueSheetGrabberView(reactContext, delegate?.grabberOptions, delegate?.accessibilityOptions).apply {
      tag = GRABBER_TAG
      id = View.generateViewId()
      onAccessibilityIncrement = { delegate?.bottomSheetViewDidAccessibilityIncrement() }
      onAccessibilityDecrement = { delegate?.bottomSheetViewDidAccessibilityDecrement() }
    }

    addView(grabberView)

    // Grabber is added after content for z-ordering, but should be announced first
    contentView?.accessibilityTraversalAfter = grabberView.id
  }

  fun updateGrabberAccessibilityValue(index: Int, detentCount: Int) {
    findViewWithTag<TrueSheetGrabberView>(GRABBER_TAG)?.updateAccessibilityValue(index, detentCount)
  }

  fun setupAccessibility() {
    ViewCompat.setAccessibilityPaneTitle(this, delegate?.accessibilityOptions?.paneTitle ?: "Bottom sheet")
  }

  // =============================================================================
  // MARK: - Grabber Tap Detection
  // =============================================================================

  private val grabberTapDetector = GestureDetector(
    context,
    object : GestureDetector.SimpleOnGestureListener() {
      override fun onSingleTapUp(e: MotionEvent): Boolean {
        delegate?.bottomSheetViewDidTapGrabber()
        return true
      }
    }
  )

  override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
    val grabber = findViewWithTag<View>(GRABBER_TAG)
    if (grabber != null) {
      val rect = Rect()
      grabber.getHitRect(rect)
      if (rect.contains(ev.x.toInt(), ev.y.toInt())) {
        if (grabberTapDetector.onTouchEvent(ev)) {
          return true
        }
      }
    }
    return super.dispatchTouchEvent(ev)
  }
}
