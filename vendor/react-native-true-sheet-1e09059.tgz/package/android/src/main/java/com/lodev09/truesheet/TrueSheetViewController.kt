package com.lodev09.truesheet

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.graphics.Canvas
import android.graphics.Color
import android.os.Build
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.ImageView
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.graphics.ColorUtils
import androidx.core.graphics.createBitmap
import androidx.core.view.isNotEmpty
import com.facebook.react.R
import com.facebook.react.uimanager.JSPointerDispatcher
import com.facebook.react.uimanager.JSTouchDispatcher
import com.facebook.react.uimanager.PixelUtil.dpToPx
import com.facebook.react.uimanager.PixelUtil.pxToDp
import com.facebook.react.uimanager.RootView
import com.facebook.react.uimanager.ThemedReactContext
import com.facebook.react.uimanager.events.EventDispatcher
import com.facebook.react.util.RNLog
import com.facebook.react.views.view.ReactViewGroup
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.lodev09.truesheet.core.AccessibilityOptions
import com.lodev09.truesheet.core.GrabberOptions
import com.lodev09.truesheet.core.TrueSheetBottomSheetBehavior
import com.lodev09.truesheet.core.TrueSheetBottomSheetView
import com.lodev09.truesheet.core.TrueSheetBottomSheetViewDelegate
import com.lodev09.truesheet.core.TrueSheetCoordinatorLayout
import com.lodev09.truesheet.core.TrueSheetCoordinatorLayoutDelegate
import com.lodev09.truesheet.core.TrueSheetDetentCalculator
import com.lodev09.truesheet.core.TrueSheetDetentCalculatorDelegate
import com.lodev09.truesheet.core.TrueSheetDimView
import com.lodev09.truesheet.core.TrueSheetDimViewDelegate
import com.lodev09.truesheet.core.TrueSheetDismissThreshold
import com.lodev09.truesheet.core.TrueSheetKeyboardObserver
import com.lodev09.truesheet.core.TrueSheetKeyboardObserverDelegate
import com.lodev09.truesheet.core.TrueSheetStackManager
import com.lodev09.truesheet.utils.Insets
import com.lodev09.truesheet.utils.KeyboardUtils
import com.lodev09.truesheet.utils.ScreenUtils
import com.lodev09.truesheet.utils.TouchEventDeduper
import kotlin.math.roundToInt

// =============================================================================
// MARK: - Data Types & Delegate Protocol
// =============================================================================

data class DetentInfo(val index: Int, val position: Float)

interface TrueSheetViewControllerDelegate {
  val eventDispatcher: EventDispatcher?
  fun findRootContainerView(): ViewGroup?
  fun viewControllerWillPresent(index: Int, position: Float, detent: Float)
  fun viewControllerDidPresent(index: Int, position: Float, detent: Float)
  fun viewControllerWillDismiss()
  fun viewControllerDidDismiss(parent: TrueSheetView?)
  fun viewControllerDidAttemptDismiss()
  fun viewControllerDidChangeDetent(index: Int, position: Float, detent: Float)
  fun viewControllerDidDragBegin(index: Int, position: Float, detent: Float)
  fun viewControllerDidDragChange(index: Int, position: Float, detent: Float)
  fun viewControllerDidDragEnd(index: Int, position: Float, detent: Float)
  fun viewControllerDidChangePosition(index: Float, position: Float, detent: Float, realtime: Boolean)
  fun viewControllerDidChangeSize(width: Int, height: Int)
  fun viewControllerWillFocus()
  fun viewControllerDidFocus()
  fun viewControllerWillBlur()
  fun viewControllerDidBlur()
  fun viewControllerDidChangeVisibility(visible: Boolean)
}

// =============================================================================
// MARK: - TrueSheetViewController
// =============================================================================

/**
 * Controls the presentation and behavior of a bottom sheet.
 *
 * Uses CoordinatorLayout with BottomSheetBehavior to manage the sheet within the activity window,
 * enabling touch pass-through to underlying views. Handles detent configuration, drag interactions,
 * keyboard avoidance, dimmed backgrounds, back button, and lifecycle events for stacked sheets.
 */
enum class TrueSheetPlacement {
  AUTOMATIC,
  LEADING,
  CENTER,
  TRAILING;

  companion object {
    fun fromString(value: String?): TrueSheetPlacement =
      when (value) {
        "leading" -> LEADING
        "center" -> CENTER
        "trailing" -> TRAILING
        else -> AUTOMATIC
      }
  }
}

enum class TrueSheetInsetAdjustment {
  AUTOMATIC,
  NEVER;

  companion object {
    fun fromString(value: String?): TrueSheetInsetAdjustment =
      when (value) {
        "never" -> NEVER
        else -> AUTOMATIC
      }
  }
}

@SuppressLint("ClickableViewAccessibility", "ViewConstructor")
class TrueSheetViewController(private val reactContext: ThemedReactContext) :
  ReactViewGroup(reactContext),
  RootView,
  TrueSheetDetentCalculatorDelegate,
  TrueSheetDimViewDelegate,
  TrueSheetCoordinatorLayoutDelegate,
  TrueSheetBottomSheetViewDelegate {

  companion object {
    const val DEFAULT_DIM_OPACITY = 0.5f
    private const val DEFAULT_MAX_WIDTH = 640 // dp
    private const val DEFAULT_CORNER_RADIUS = 16 // dp
    private const val DEFAULT_PLACEMENT_OFFSET = 16 // dp
    private const val TRANSLATE_ANIMATION_DURATION = 200L
    private const val DISMISS_DURATION = 200L
    private const val SCREEN_FADE_DURATION = 150L

    // Mirrors BottomSheetBehavior.HIDE_THRESHOLD — how far past the lowest stop,
    // as a fraction of its height, a release hides a dismissible sheet
    private const val HIDE_THRESHOLD = 0.5f
  }

  // =============================================================================
  // MARK: - Types
  // =============================================================================

  private sealed class InteractionState {
    data object Idle : InteractionState()
    data class Dragging(val startTop: Int) : InteractionState()
    data object Reconfiguring : InteractionState()
  }

  // =============================================================================
  // MARK: - Properties
  // =============================================================================

  var delegate: TrueSheetViewControllerDelegate? = null

  // CoordinatorLayout components (replaces DialogFragment)
  internal var sheetView: TrueSheetBottomSheetView? = null
  internal var coordinatorLayout: TrueSheetCoordinatorLayout? = null
  private var dimView: TrueSheetDimView? = null
  private var parentDimView: TrueSheetDimView? = null

  // Presentation State
  var isPresented = false
    private set

  var isSheetVisible = false
    private set

  var currentDetentIndex: Int = -1
    private set

  // Target detent index during an in-flight resize animation. -1 when idle.
  // Used by setupSheetDetents so a layout-driven reconfigure during the
  // animation doesn't snap the sheet back to the stale currentDetentIndex.
  private var pendingDetentIndex: Int = -1

  private val isSettlingInPlace: Boolean
    get() = !isBeingDismissed && pendingDetentIndex >= 0 && pendingDetentIndex == currentDetentIndex

  private var interactionState: InteractionState = InteractionState.Idle

  // A content/header/footer size change arrived mid-drag — reconfiguring then
  // would reset behavior state and kill the gesture, so it's applied on settle.
  private var hasPendingSizeChange = false
  internal var isBeingDismissed = false
    private set
  var wasHiddenByScreen = false
  private var shouldAnimatePresent = false
  private var isPresentAnimating = false

  private var lastStateWidth: Int = 0
  private var lastStateHeight: Int = 0
  private var lastEmittedPositionPx: Int = -1

  // Keyboard State
  private var detentIndexBeforeKeyboard: Int = -1
  private var isKeyboardDismissProgrammatic = false

  // The keyboard hid under a touch (e.g. keyboardDismissMode="on-drag") — the
  // keyboard stops stay until it lifts. Settling or moving the stops under a
  // scrolling finger makes the behavior's nested pre-scroll snap the sheet and
  // jump the content.
  private var isKeyboardSettleDeferred = false

  // Sheet top when a keyboard-floor drag was released; -1 once the settle target is known
  private var keyboardSettleStartTop = -1
  private var focusedViewBeforeBlur: View? = null

  // Promises
  var presentPromise: (() -> Unit)? = null
  var resizePromise: (() -> Unit)? = null
  var dismissPromise: (() -> Unit)? = null

  // For stacked sheets
  var parentSheetView: TrueSheetView? = null

  // Helper Objects
  private var keyboardObserver: TrueSheetKeyboardObserver? = null
  internal val detentCalculator = TrueSheetDetentCalculator(reactContext).apply {
    delegate = this@TrueSheetViewController
  }

  // Touch Dispatchers
  private val jsTouchDispatcher = JSTouchDispatcher(this)
  private val jsPointerDispatcher = JSPointerDispatcher(this)
  private val touchDeduper = TouchEventDeduper()

  private val eventDispatcher
    get() = delegate?.eventDispatcher

  // Detent Configuration
  override var maxContentHeight: Int? = null
  override var maxContentWidth: Int? = null
  override var placement: TrueSheetPlacement = TrueSheetPlacement.AUTOMATIC
  override var placementOffset: Int = DEFAULT_PLACEMENT_OFFSET.dpToPx().toInt()
  override var detents: MutableList<Double> = mutableListOf(0.5, 1.0)

  // Appearance Configuration
  var dimmed = true
  var dimmedDetentIndex = 0
  var dimColor: Int = Color.BLACK
  var dimOpacity: Float = DEFAULT_DIM_OPACITY
  private var dimProgress = 0f
  override var grabber: Boolean = true
  override var grabberOptions: GrabberOptions? = null
  override var accessibilityOptions: AccessibilityOptions? = null
  var backgroundColor: Int? = null
  var detentBackgrounds: List<Int?> = emptyList()
  private var displayedBackgroundIndex = 0
  private var backgroundAnimator: ValueAnimator? = null
  private var targetBackgroundColor: Int? = null
  override var sheetBackgroundColor: Int? = null
    private set
  var insetAdjustment: TrueSheetInsetAdjustment = TrueSheetInsetAdjustment.AUTOMATIC

  var scrollableOptions: ScrollableOptions? = null
    set(value) {
      field = value
      behavior?.scrollingExpandsSheet = value?.scrollingExpandsSheet ?: true
    }

  // React tag of the user-provided scrollable within the content (see the scrollableRef prop)
  var scrollableHandle: Int = -1

  override var sheetCornerRadius: Float = DEFAULT_CORNER_RADIUS.dpToPx()
    set(value) {
      field = if (value < 0) DEFAULT_CORNER_RADIUS.dpToPx() else value
      if (isPresented) sheetView?.setupBackground()
    }

  override var sheetElevation: Float = -1f
    set(value) {
      field = value
      if (isPresented) sheetView?.setupElevation()
    }

  var dismissible: Boolean = true
    set(value) {
      field = value
      behavior?.isHideable = value
    }

  override var draggable: Boolean = true
    set(value) {
      field = value
      behavior?.isDraggable = value
      if (isPresented) sheetView?.setupGrabber()
    }

  var dismissThreshold: TrueSheetDismissThreshold = TrueSheetDismissThreshold.HALF
    set(value) {
      field = value
      behavior?.dismissThreshold = value
    }

  // =============================================================================
  // MARK: - Computed Properties
  // =============================================================================

  // Behavior
  private val behavior: TrueSheetBottomSheetBehavior<TrueSheetBottomSheetView>?
    get() = sheetView?.behavior

  internal val containerView: TrueSheetContainerView?
    get() = if (this.isNotEmpty()) getChildAt(0) as? TrueSheetContainerView else null

  // Screen Measurements
  override val screenHeight: Int
    get() = ScreenUtils.getScreenHeight(reactContext)

  val screenWidth: Int
    get() = ScreenUtils.getScreenWidth(reactContext)

  // Cached per layout/configuration pass — the WindowManager and
  // rootWindowInsets queries behind these allocate, and they're read many
  // times per animation frame (position emission, detent interpolation,
  // stacked sheet sync)
  private var cachedRealScreenHeight: Int = 0
  private var cachedInsets: Insets? = null

  private fun invalidateScreenMetrics() {
    cachedRealScreenHeight = 0
    cachedInsets = null
  }

  // Includes system bars for accurate positioning
  override val realScreenHeight: Int
    get() {
      if (cachedRealScreenHeight == 0) {
        cachedRealScreenHeight = ScreenUtils.getRealScreenHeight(reactContext)
      }
      return cachedRealScreenHeight
    }

  private val insets: Insets
    get() = cachedInsets ?: ScreenUtils.getInsets(reactContext).also { cachedInsets = it }

  // Content Measurements
  // Cached values used during dismiss when container is unmounted
  private var cachedContentHeight: Int = 0
  private var cachedHeaderHeight: Int = 0
  private var cachedFooterHeight: Int = 0
  private var cachedPeekContentHeight: Int = 0

  override val contentHeight: Int
    get() = containerView?.contentHeight ?: cachedContentHeight

  override val headerHeight: Int
    get() = containerView?.headerHeight ?: cachedHeaderHeight

  override var absoluteHeader: Boolean = false

  override val footerHeight: Int
    get() = containerView?.footerHeight ?: cachedFooterHeight

  override var absoluteFooter: Boolean = false

  override val footerInsetAdjustment: Boolean
    get() = absoluteFooter && scrollableHandle > 0 && scrollableOptions?.contentInsetAdjustment?.footer != false

  override val peekContentHeight: Int
    get() = containerView?.peekContentHeight ?: cachedPeekContentHeight

  // Insets
  // Target keyboard height used for detent calculations
  override val keyboardInset: Int
    get() = keyboardObserver?.targetHeight ?: 0

  // Current animated keyboard height for positioning
  private val currentKeyboardInset: Int
    get() = keyboardObserver?.currentHeight ?: 0

  private val isKeyboardTransitioning: Boolean
    get() = keyboardObserver?.isTransitioning ?: false

  // The footer slides every frame until the sheet and keyboard come to rest
  private val isSheetMoving: Boolean
    get() = isPresentAnimating ||
      isKeyboardTransitioning ||
      behavior?.state == BottomSheetBehavior.STATE_DRAGGING ||
      behavior?.state == BottomSheetBehavior.STATE_SETTLING

  // Keyboard is up or animating — detents are (or are about to be) keyboard-shifted
  val isKeyboardActive: Boolean
    get() = keyboardInset > 0 || isKeyboardTransitioning

  // While the keyboard holds the sheet up, the keyboard-free first detent is the
  // collapsed stop — landing there dismisses the keyboard, and (when dismissible)
  // dragging more than half its height below it hides the sheet too, like iOS.
  override val hasKeyboardFloor: Boolean
    get() = keyboardInset > 0

  // The detent JS last heard about — the keyboard expansion is never reported
  private val knownDetentIndex: Int
    get() = if (detentIndexBeforeKeyboard >= 0) detentIndexBeforeKeyboard else currentDetentIndex

  fun isFocusedViewWithinSheet(): Boolean {
    val sheet = sheetView ?: return false
    return keyboardObserver?.isFocusedViewWithinSheet(sheet) ?: false
  }

  val bottomInset: Int
    get() = if (edgeToEdgeEnabled) insets.bottom else 0

  override val topInset: Int
    get() = if (edgeToEdgeEnabled) insets.top else 0

  override val contentBottomInset: Int
    get() = if (insetAdjustment == TrueSheetInsetAdjustment.AUTOMATIC) bottomInset else 0

  @Suppress("KotlinConstantConditions", "SimplifyBooleanWithConstants")
  private val edgeToEdgeEnabled: Boolean
    get() {
      val defaultEnabled = Build.VERSION.SDK_INT >= 36
      return BuildConfig.EDGE_TO_EDGE_ENABLED || defaultEnabled
    }

  // Sheet State
  val isSettling: Boolean
    get() = behavior?.state == BottomSheetBehavior.STATE_SETTLING

  val isExpanded: Boolean
    get() {
      val sheetTop = sheetView?.top ?: return false
      return sheetTop <= topInset
    }

  val currentTranslationY: Int
    get() = sheetView?.translationY?.toInt() ?: 0

  override val isTopmostSheet: Boolean
    get() {
      val hostView = delegate as? TrueSheetView ?: return true
      return TrueSheetStackManager.isTopmostSheet(hostView)
    }

  private val dimViews: List<TrueSheetDimView>
    get() = listOfNotNull(dimView, parentDimView)

  val isDimmedAtCurrentDetent: Boolean
    get() = isDimmedAtDetentIndex(currentDetentIndex)

  fun isDimmedAtDetentIndex(index: Int): Boolean = dimmed && index >= dimmedDetentIndex

  // =============================================================================
  // MARK: - Sheet Creation & Cleanup
  // =============================================================================

  fun createSheet() {
    if (coordinatorLayout != null) return

    // Create coordinator layout
    coordinatorLayout = TrueSheetCoordinatorLayout(reactContext).apply {
      delegate = this@TrueSheetViewController
    }

    sheetView = TrueSheetBottomSheetView(reactContext).apply {
      delegate = this@TrueSheetViewController
    }
  }

  private fun cleanupSheet() {
    cleanupKeyboardObserver()
    backgroundAnimator?.cancel()
    backgroundAnimator = null
    targetBackgroundColor = null
    sheetView?.animate()?.cancel()

    // Cleanup dim views
    dimView?.detach()
    dimView = null
    parentDimView?.detach()
    parentDimView = null

    // Cleanup snapshot
    removeSheetSnapshot()

    // Detach content from sheet
    sheetView?.removeView(this)

    containerView?.cleanupKeyboardHandler()
    coordinatorLayout = null
    sheetView = null

    interactionState = InteractionState.Idle
    hasPendingSizeChange = false
    isBeingDismissed = false
    isPresented = false
    isSheetVisible = false
    wasHiddenByScreen = false
    cachedContentHeight = 0
    cachedHeaderHeight = 0
    isPresentAnimating = false
    lastEmittedPositionPx = -1
    detentIndexBeforeKeyboard = -1
    pendingDetentIndex = -1
    isKeyboardDismissProgrammatic = false
    isKeyboardSettleDeferred = false
    focusedViewBeforeBlur = null
    shouldAnimatePresent = true
  }

  private var snapshotView: View? = null

  fun createSheetSnapshot() {
    if (!isPresented) return
    val sheet = sheetView ?: return
    if (sheet.width <= 0 || sheet.height <= 0) return

    val bitmap = createBitmap(sheet.width, sheet.height)
    val canvas = Canvas(bitmap)
    sheet.draw(canvas)

    val snapshot = ImageView(reactContext).apply {
      setImageBitmap(bitmap)
      layoutParams = LayoutParams(sheet.width, sheet.height)
    }

    sheet.addView(snapshot, 0)
    snapshotView = snapshot
  }

  fun removeSheetSnapshot() {
    snapshotView?.let {
      (it as? ImageView)?.setImageDrawable(null)
      sheetView?.removeView(it)
    }
    snapshotView = null
  }

  // =============================================================================
  // MARK: - TrueSheetCoordinatorLayout.Delegate
  // =============================================================================

  override fun coordinatorLayoutDidLayout(changed: Boolean) {
    if (changed) invalidateScreenMetrics()

    if (isPresented && changed) {
      setupSheetDetentsForSizeChange()
    }
  }

  override fun coordinatorLayoutDidChangeConfiguration() {
    invalidateScreenMetrics()
    if (!isPresented) return

    sheetView?.updateGravity()
    updateBehaviorMaxWidth()
    updateStateDimensions()
    sheetView?.let { emitChangePositionDelegate(it.top, realtime = false) }
  }

  override fun findScrollView(): ViewGroup? = containerView?.contentView?.findScrollView()
  override fun findSheetView(): TrueSheetBottomSheetView? = sheetView

  override fun coordinatorLayoutDidPullDown(overdragPx: Int, keyboardWasVisible: Boolean) {
    if (!isPresented || dismissible || !draggable) return
    val sheet = sheetView ?: return

    // Only a pull clamped at the lowest stop is a blocked drag-to-dismiss — a
    // child that swallowed the gesture higher up isn't
    val lowestTop = detentCalculator.getLowestSheetTop()
    if (sheet.top < lowestTop) return

    if (keyboardWasVisible) {
      // A sheet that couldn't move at all (first detent already full height) never
      // began a drag, so the keyboard is still up — dismiss it here
      if (hasKeyboardFloor && !isKeyboardDismissProgrammatic) commitDetentAndDismissKeyboard(0, sheet)

      // Past the floor by the distance that would hide a dismissible sheet, like iOS
      val floorHeight = realScreenHeight - lowestTop
      if (overdragPx < floorHeight * HIDE_THRESHOLD) return
    }

    delegate?.viewControllerDidAttemptDismiss()
  }

  override fun coordinatorLayoutDidEndTouch() {
    if (!isKeyboardSettleDeferred) return
    isKeyboardSettleDeferred = false
    setupSheetDetentsForSizeChange()
  }

  // =============================================================================
  // MARK: - TrueSheetDimViewDelegate
  // =============================================================================

  override fun dimViewDidTap() {
    val hostView = delegate as? TrueSheetView ?: return

    val children = TrueSheetStackManager.getSheetsAbove(hostView)
    val topmostChild = children.firstOrNull()?.viewController

    // If topmost child is dimmed, only handle that child
    if (topmostChild?.isDimmedAtCurrentDetent == true) {
      if (topmostChild.dismissible) {
        topmostChild.dismiss(animated = true)
      }
      return
    }

    // Pass through to parent - dismiss all if possible
    val allDismissible = dismissible && children.all { it.viewController.dismissible }
    if (allDismissible) {
      children.forEach { it.viewController.dismiss(animated = true) }
    }

    if (dismissible) {
      dismiss(animated = true)
    } else if (parentSheetView == null && isDimmedAtCurrentDetent && dimmedDetentIndex > 0) {
      setStateForDetentIndex(dimmedDetentIndex - 1)
    }
  }

  // =============================================================================
  // MARK: - TrueSheetBottomSheetViewDelegate - Grabber Tap
  // =============================================================================

  override fun bottomSheetViewDidTapGrabber() {
    val nextIndex = (currentDetentIndex + 1) % detents.size
    if (nextIndex == 0 && detents.size == 1) {
      if (dismissible) {
        dismiss(animated = true)
      } else {
        delegate?.viewControllerDidAttemptDismiss()
      }
    } else {
      resize(nextIndex)
    }
  }

  override fun bottomSheetViewDidAccessibilityIncrement() {
    if (currentDetentIndex < detents.size - 1) {
      resize(currentDetentIndex + 1)
    }
  }

  override fun bottomSheetViewDidAccessibilityDecrement() {
    if (currentDetentIndex > 0) {
      resize(currentDetentIndex - 1)
    } else if (dismissible) {
      dismiss(animated = true)
    } else {
      delegate?.viewControllerDidAttemptDismiss()
    }
  }

  // =============================================================================
  // MARK: - BottomSheetCallback
  // =============================================================================

  private val sheetCallback = object : BottomSheetBehavior.BottomSheetCallback() {
    override fun onStateChanged(sheetView: View, newState: Int) {
      handleStateChanged(sheetView, newState)
    }

    override fun onSlide(sheetView: View, slideOffset: Float) {
      handleSlide(sheetView)
    }
  }

  private fun handleStateChanged(sheetView: View, newState: Int) {
    if (newState == BottomSheetBehavior.STATE_HIDDEN) {
      if (isBeingDismissed) return
      isBeingDismissed = true
      dismissKeyboard()
      emitWillDismissEvents()
      finishDismiss()
      return
    }

    // The slide-out owns the sheet now — a present settle landing mid-dismiss must not finish the present
    if (!isPresented || isBeingDismissed) return

    when (newState) {
      BottomSheetBehavior.STATE_DRAGGING -> handleDragBegin(sheetView)

      BottomSheetBehavior.STATE_SETTLING -> handleSettling(sheetView)

      BottomSheetBehavior.STATE_EXPANDED,
      BottomSheetBehavior.STATE_COLLAPSED,
      BottomSheetBehavior.STATE_HALF_EXPANDED -> handleStateSettled(sheetView, newState)

      else -> {}
    }
  }

  private fun handleSlide(sheetView: View) {
    // Skip during dismiss animation
    if (isBeingDismissed) return

    val behavior = behavior ?: return

    if (interactionState is InteractionState.Dragging || pendingDetentIndex >= 0) {
      updateStateDimensionsForPosition(sheetView.top)
    }

    when (behavior.state) {
      BottomSheetBehavior.STATE_DRAGGING -> handleDragChange(sheetView)

      BottomSheetBehavior.STATE_SETTLING -> {
        handleDragChange(sheetView)
        dismissKeyboardForSettleTarget(sheetView)
      }

      else -> { }
    }

    emitChangePositionDelegate(sheetView.top)

    // Drive the parent's stack translation from our actual frame position —
    // an independently-timed animation lags behind (e.g. auto detent shrink)
    // and reveals the parent above this sheet's top edge. Skipped while
    // dragging so the parent stays put during drag-to-dismiss, and while the
    // keyboard is active so growing for it doesn't move the parent (like iOS).
    if (!isPresentAnimating && interactionState !is InteractionState.Dragging && !isKeyboardActive) {
      syncParentTranslation(sheetView.top)
    }

    // Position on every slide frame — during keyboard transitions the IME
    // animation callbacks are sparser than the sheet's settle frames, and the
    // footer rides the sheet between them, jittering against the keyboard.
    // positionFooter derives from current state, so double-driving it with
    // keyboardDidChangeHeight is harmless.
    positionFooter()

    if (!isKeyboardTransitioning) {
      updateDimAmount(sheetView.top)
    }
  }

  private fun handleStateSettled(sheetView: View, newState: Int) {
    // The settle's last slide frame has positioned the footer
    containerView?.footerView?.syncTranslationState()

    if (interactionState is InteractionState.Reconfiguring) return

    // A release already at a stop settles without a slide frame
    keyboardSettleStartTop = -1

    // Sheet has reached a stable state — any in-flight resize target is now stale,
    // whether settled at the target, interrupted by drag, or superseded.
    pendingDetentIndex = -1

    val index = detentCalculator.getDetentIndexForState(newState) ?: run {
      // Unmapped settle — end any drag anyway so deferred size changes aren't
      // dropped forever (a leaked Dragging state skips every reconfigure)
      if (interactionState is InteractionState.Dragging) {
        interactionState = InteractionState.Idle
      }
      flushPendingSizeChange()
      return
    }
    val position = getPositionDpForView(sheetView)
    val detentInfo = DetentInfo(index, position)

    // Handle present animation completion
    if (isPresentAnimating) {
      isPresentAnimating = false
      finishPresent()
      flushPendingSizeChange()
      return
    }

    val wasDragging = interactionState is InteractionState.Dragging

    when (interactionState) {
      is InteractionState.Dragging -> {
        val detent = detentCalculator.getDetentValueForIndex(detentInfo.index)
        delegate?.viewControllerDidDragEnd(detentInfo.index, detentInfo.position, detent)

        // Skip detent change if keyboard inset is still active — the keyboard floor
        // landing below commits the detent instead.
        if (keyboardInset == 0) {
          val changed = detentInfo.index != knownDetentIndex
          detentIndexBeforeKeyboard = -1
          if (detentInfo.index != currentDetentIndex) {
            currentDetentIndex = detentInfo.index
            setupDimmedBackground()
          }
          if (changed) {
            delegate?.viewControllerDidChangeDetent(detentInfo.index, detentInfo.position, detent)
            this@TrueSheetViewController.sheetView?.updateGrabberAccessibilityValue(detentInfo.index, detents.size)
          }
        }

        interactionState = InteractionState.Idle
      }

      else -> {
        if (detentInfo.index != currentDetentIndex) {
          currentDetentIndex = detentInfo.index
          if (!isKeyboardTransitioning) {
            val detent = detentCalculator.getDetentValueForIndex(detentInfo.index)
            delegate?.viewControllerDidChangeDetent(detentInfo.index, detentInfo.position, detent)
          }
          this@TrueSheetViewController.sheetView?.updateGrabberAccessibilityValue(detentInfo.index, detents.size)
        }
      }
    }

    if (hasKeyboardFloor && wasDragging && newState != BottomSheetBehavior.STATE_EXPANDED) {
      // Dragged down onto a keyboard-free stop (the floor or the keyboard detent) —
      // dismiss the keyboard and commit that detent. keyboardWillHide reconfigures
      // the detents (and the container) to it.
      commitDetentAndDismissKeyboard(index, sheetView)
    } else {
      updateStateDimensions()
    }

    if (!isKeyboardTransitioning) {
      updateDimAmount(animated = true)
    }

    TrueSheetStackManager.updateBackgroundAccessibility()

    flushPendingSizeChange()
  }

  private fun flushPendingSizeChange() {
    if (!hasPendingSizeChange) return
    hasPendingSizeChange = false
    setupSheetDetentsForSizeChange()
  }

  // =============================================================================
  // MARK: - Screen Visibility
  // =============================================================================

  private fun setSheetVisibility(visible: Boolean) {
    coordinatorLayout?.visibility = if (visible) VISIBLE else GONE
    dimViews.forEach { it.visibility = if (visible) VISIBLE else INVISIBLE }
  }

  internal fun hideForScreen() {
    val sheet = sheetView ?: run {
      RNLog.e(reactContext, "TrueSheet: sheetView is null in hideForScreen")
      return
    }

    isSheetVisible = false
    wasHiddenByScreen = true
    TrueSheetStackManager.updateBackgroundAccessibility()
    delegate?.viewControllerDidChangeVisibility(false)
    dimViews.forEach { it.animate().alpha(0f).setDuration(SCREEN_FADE_DURATION).start() }
    sheet.animate()
      .alpha(0f)
      .setDuration(SCREEN_FADE_DURATION)
      .withEndAction {
        setSheetVisibility(false)
      }
      .start()

    // This will hide parent sheets first
    parentSheetView?.viewController?.hideForScreen()
  }

  internal fun showAfterScreen() {
    isSheetVisible = true
    delegate?.viewControllerDidChangeVisibility(true)
    setSheetVisibility(true)
    sheetView?.alpha = 1f
    updateDimAmount(animated = true)
    TrueSheetStackManager.updateBackgroundAccessibility()
  }

  /**
   * Re-applies hidden state after returning from background.
   * Android may restore visibility on activity resume, so we need to hide it again.
   */
  fun reapplyHiddenState() {
    if (!wasHiddenByScreen) return
    setSheetVisibility(false)
  }

  // =============================================================================
  // MARK: - Presentation
  // =============================================================================

  fun present(detentIndex: Int, animated: Boolean = true) {
    val coordinator = this.coordinatorLayout ?: return
    val sheet = this.sheetView ?: return
    if (isPresented) return

    invalidateScreenMetrics()
    shouldAnimatePresent = animated
    currentDetentIndex = detentIndex
    interactionState = InteractionState.Idle

    // Setup sheet in coordinator layout
    setupSheetInCoordinator(coordinator, sheet)

    emitWillPresentEvents()

    setupSheetDetents()
    setupDimmedBackground()
    setupKeyboardObserver()
    // Before the slide, so an input focused in onWillPresent insets the scrollable
    containerView?.setupKeyboardHandler()

    displayedBackgroundIndex = detentIndex
    setupBackground(animated = false)
    sheet.setupBackground()
    sheet.setupElevation()
    sheet.setupGrabber()
    sheet.setupAccessibility()

    if (shouldAnimatePresent) {
      isPresentAnimating = true
      post { setStateForDetentIndex(currentDetentIndex) }
    } else {
      setStateForDetentIndex(currentDetentIndex)
      post {
        emitChangePositionDelegate(detentCalculator.getSheetTopForDetentIndex(currentDetentIndex))
        updateDimAmount()
        finishPresent()
      }
    }

    isPresented = true
    isSheetVisible = true
  }

  fun resize(detentIndex: Int) {
    if (!isPresented) return

    // Commit the new index so keyboardWillHide restores to it instead of the stale
    // one; the sheet keeps avoiding the keyboard meanwhile
    if (detentIndexBeforeKeyboard >= 0) {
      detentIndexBeforeKeyboard = detentIndex
      if (hasKeyboardFloor) {
        resizePromise?.invoke()
        resizePromise = null
        return
      }
    }

    pendingDetentIndex = detentIndex
    setupDimmedBackground()
    setStateForDetentIndex(detentIndex)
    resizePromise?.invoke()
    resizePromise = null
  }

  private fun setupSheetInCoordinator(coordinator: TrueSheetCoordinatorLayout, sheet: TrueSheetBottomSheetView) {
    // Add this controller as content to the sheet
    (parent as? ViewGroup)?.removeView(this)
    sheet.addView(this)

    // Create layout params with behavior
    val params = sheet.createLayoutParams()

    @Suppress("UNCHECKED_CAST")
    val behavior = params.behavior as TrueSheetBottomSheetBehavior<TrueSheetBottomSheetView>

    // Configure behavior
    behavior.isHideable = true
    behavior.isDraggable = draggable
    behavior.scrollingExpandsSheet = scrollableOptions?.scrollingExpandsSheet ?: true
    behavior.dismissThreshold = dismissThreshold
    behavior.lowestSheetTop = { detentCalculator.getLowestSheetTop() }
    behavior.state = BottomSheetBehavior.STATE_HIDDEN
    behavior.addBottomSheetCallback(sheetCallback)

    // Add sheet to coordinator
    coordinator.addView(sheet, params)
  }

  fun dismiss(animated: Boolean = true) {
    if (isBeingDismissed) return

    isBeingDismissed = true
    dismissKeyboard()
    emitWillDismissEvents()

    if (animated) {
      animateDismiss()
    } else {
      emitChangePositionDelegate(realScreenHeight)
      finishDismiss()
    }
  }

  private fun dismissKeyboard() {
    isKeyboardDismissProgrammatic = true
    KeyboardUtils.dismiss(reactContext)

    // Clear focus from any focused view within the sheet to prevent
    // Android from autofocusing the next focusable view on the main
    // screen when the sheet is removed from the hierarchy.
    sheetView?.findFocus()?.clearFocus()
  }

  fun handleBackPress() {
    if (dismissible) {
      dismiss(animated = true)
    }
  }

  private fun animateDismiss() {
    val sheet = sheetView ?: run {
      finishDismiss()
      return
    }

    // Bring the parent back alongside the slide-out (like iOS) instead of after it
    parentSheetView?.resetTranslation()

    sheet.animate()
      .y(realScreenHeight.toFloat())
      .setDuration(DISMISS_DURATION)
      .setInterpolator(android.view.animation.AccelerateInterpolator())
      .setUpdateListener { updateSheetVisuals(sheet.y.toInt()) }
      .withEndAction { finishDismiss() }
      .start()
  }

  private fun finishPresent() {
    // Restore isHideable to actual value after present animation
    behavior?.isHideable = dismissible

    val (index, position, detent) = getDetentInfoWithValue(currentDetentIndex)
    parentSheetView?.viewControllerDidBlur()
    delegate?.viewControllerDidPresent(index, position, detent)
    delegate?.viewControllerDidFocus()
    sheetView?.updateGrabberAccessibilityValue(index, detents.size)

    TrueSheetStackManager.updateBackgroundAccessibility()
    // Move accessibility focus into the sheet
    sheetView?.sendAccessibilityEvent(AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED)

    presentPromise?.invoke()
    presentPromise = null
  }

  private fun finishDismiss() {
    TrueSheetStackManager.updateBackgroundAccessibility()
    restoreFocusedView()
    emitDidDismissEvents()
    cleanupSheet()
  }

  // =============================================================================
  // MARK: - Sheet Configuration
  // =============================================================================

  fun setupSheetDetents(applyState: Boolean = true) {
    val behavior = this.behavior ?: run {
      RNLog.e(reactContext, "TrueSheet: behavior is null in setupSheetDetents")
      return
    }

    containerView?.let {
      cachedContentHeight = it.contentHeight
      cachedHeaderHeight = it.headerHeight
      cachedFooterHeight = it.footerHeight
      cachedPeekContentHeight = it.peekContentHeight
    }

    interactionState = InteractionState.Reconfiguring

    behavior.isFitToContents = false

    val maxAvailableHeight = realScreenHeight - topInset

    // With a keyboard floor only the last detent stays keyboard-shifted; the
    // collapsed and half stops are the keyboard-free first and second detents,
    // so a short drag down from the keyboard-expanded sheet rests at the second
    // and a long one at the first, like iOS
    val peekHeight = minOf(detentCalculator.getDetentHeight(detents[0], includeKeyboard = !hasKeyboardFloor), maxAvailableHeight)

    val halfExpandedDetentHeight = when (detents.size) {
      1 -> peekHeight
      else -> detentCalculator.getDetentHeight(detents[1], includeKeyboard = !hasKeyboardFloor)
    }

    val maxDetentHeight = minOf(detentCalculator.getDetentHeight(detents.last()), maxAvailableHeight)

    val adjustedHalfExpandedHeight = minOf(halfExpandedDetentHeight, maxAvailableHeight)
    val halfExpandedRatio = (adjustedHalfExpandedHeight.toFloat() / realScreenHeight.toFloat())

    val expandedOffset = realScreenHeight - maxDetentHeight

    // fitToContents works better with <= 2 detents when no expanded offset, but
    // it drops the half stop the keyboard floor relies on
    val fitToContents = !hasKeyboardFloor && detents.size < 3 && expandedOffset == 0

    configureDetents(
      behavior = behavior,
      peekHeight = peekHeight,
      halfExpandedRatio = halfExpandedRatio,
      expandedOffset = expandedOffset,
      fitToContents = fitToContents,
      animate = isPresented
    )

    if (isPresented && applyState) {
      // Prefer the pending target while a resize animation is in flight so a
      // layout-driven reconfigure doesn't revert to the stale currentDetentIndex.
      val targetIndex = if (pendingDetentIndex >= 0) pendingDetentIndex else currentDetentIndex

      // Track the settle like resize() — the container (and the footer pinned
      // to its bottom) follows the sheet's visible height instead of jumping
      // to the target and riding the animation
      pendingDetentIndex = targetIndex
      sheetView?.let { updateStateDimensionsForPosition(it.top) }
      setStateForDetentIndex(targetIndex)

      // Already at the target — no slide frames will follow
      if (!isSettling) {
        pendingDetentIndex = -1
        updateStateDimensions()
      }
    } else {
      updateStateDimensions()
    }

    interactionState = InteractionState.Idle
  }

  private fun configureDetents(
    behavior: BottomSheetBehavior<TrueSheetBottomSheetView>,
    peekHeight: Int,
    halfExpandedRatio: Float,
    expandedOffset: Int,
    fitToContents: Boolean,
    animate: Boolean
  ) {
    behavior.apply {
      isFitToContents = fitToContents
      skipCollapsed = false
      setPeekHeight(peekHeight, animate)
      this.halfExpandedRatio = halfExpandedRatio.coerceIn(0.01f, 0.999f)
      this.expandedOffset = expandedOffset
    }
  }

  fun setupSheetDetentsForSizeChange() {
    // Reconfiguring while the container tracks the sheet can interrupt its
    // motion. Apply content size changes once the drag or resize settles, or
    // the touch holding a deferred keyboard settle lifts.
    if (interactionState is InteractionState.Dragging || isSettling || isKeyboardSettleDeferred) {
      hasPendingSizeChange = true
      return
    }
    hasPendingSizeChange = false

    setupSheetDetents()
    positionFooter()
  }

  fun setStateForDetentIndex(index: Int) {
    behavior?.state = detentCalculator.getStateForDetentIndex(index)
  }

  // =============================================================================
  // MARK: - Dimmed Background
  // =============================================================================

  fun setupBackground(animated: Boolean = true) {
    val sheet = sheetView ?: return
    val color = detentBackgrounds.getOrNull(displayedBackgroundIndex)
      ?: backgroundColor ?: sheet.getDefaultBackgroundColor()
    if (animated && color == targetBackgroundColor) return

    backgroundAnimator?.cancel()
    targetBackgroundColor = color
    val startColor = sheetBackgroundColor ?: color
    if (!animated || !isPresented || startColor == color) {
      sheetBackgroundColor = color
      sheet.updateBackgroundColor(color)
      return
    }
    backgroundAnimator = ValueAnimator.ofArgb(startColor, color).apply {
      duration = 200L
      addUpdateListener {
        sheetBackgroundColor = it.animatedValue as Int
        sheet.updateBackgroundColor(it.animatedValue as Int)
      }
      start()
    }
  }

  fun setupDimmedBackground() {
    val coordinator = this.coordinatorLayout ?: run {
      RNLog.e(reactContext, "TrueSheet: coordinatorLayout is null in setupDimmedBackground")
      return
    }

    if (dimmed) {
      val parentDimVisible = (parentSheetView?.viewController?.dimView?.alpha ?: 0f) > 0f

      if (dimView == null) {
        dimView = TrueSheetDimView(reactContext).apply {
          delegate = this@TrueSheetViewController
          setDimColor(dimColor)
        }
      }
      if (!parentDimVisible) {
        dimView?.attachToCoordinator(coordinator)
      }

      // Attach dim view to parent sheet if stacked
      val parentController = parentSheetView?.viewController
      val parentBottomSheet = parentController?.sheetView
      if (parentBottomSheet != null) {
        if (parentDimView == null) {
          parentDimView = TrueSheetDimView(reactContext).apply {
            delegate = this@TrueSheetViewController
            setDimColor(dimColor)
          }
        }
        parentDimView?.attach(parentBottomSheet, parentController.sheetCornerRadius)
      }
    } else {
      dimView?.detach()
      dimView = null
      parentDimView?.detach()
      parentDimView = null
    }
  }

  fun updateDimAmount(sheetTop: Int? = null, animated: Boolean = false) {
    if (dimmed) {
      // While keyboard is active or transitioning, or settling in place after a content
      // resize (the detent top moves before the sheet does), use the target detent position
      val top = if (isKeyboardActive || isSettlingInPlace) {
        detentCalculator.getSheetTopForDetentIndex(currentDetentIndex)
      } else {
        val keyboardOffset = if (isBeingDismissed) 0 else currentKeyboardInset
        (sheetTop ?: sheetView?.top ?: return) + keyboardOffset
      }

      dimProgress = dimView?.calculateProgress(
        top,
        dimmedDetentIndex,
        detentCalculator::getSheetTopForDetentIndex
      ) ?: 0f
      applyDimAmount(animated)
    }

    // The sheets below blend this sheet's dim into theirs
    var parent = parentSheetView?.viewController
    while (parent != null) {
      parent.applyDimAmount(animated)
      parent = parent.parentSheetView?.viewController
    }
  }

  /**
   * Dims by this sheet's progress, blending in the dim of the sheets presented on top by theirs,
   * so everything below the topmost sheet dims with its color and opacity.
   */
  private fun applyDimAmount(animated: Boolean) {
    if (!dimmed) return

    var color = dimColor
    var opacity = dimOpacity
    (delegate as? TrueSheetView)?.let { hostView ->
      TrueSheetStackManager.getSheetsAbove(hostView).asReversed().forEach {
        val child = it.viewController
        if (!child.dimmed) return@forEach
        val below = (1f - child.dimProgress) * opacity
        val above = child.dimProgress * child.dimOpacity
        if (below + above > 0f) color = ColorUtils.blendARGB(color, child.dimColor, above / (below + above))
        opacity = below + above
      }
    }

    // Keep opacity in the color so a transparent dim still receives touches.
    color = ColorUtils.setAlphaComponent(color, (Color.alpha(color) * opacity).roundToInt())
    dimViews.forEach {
      it.setDimColor(color)
      if (animated) it.animate().alpha(dimProgress).setDuration(200).start() else it.alpha = dimProgress
    }
  }

  // =============================================================================
  // MARK: - Footer Positioning
  // =============================================================================

  var footerKeyboardOffset: Int = 0

  /**
   * false keeps an absolute footer pinned to the sheet's bottom edge behind
   * the keyboard instead of rising above it.
   */
  override var footerAvoidsKeyboard: Boolean = true

  fun positionFooter() {
    if (!isPresented) return
    val footerView = containerView?.footerView ?: return
    val sheet = sheetView ?: return

    // A relative footer is laid out by Yoga (pinned to the container's bottom
    // edge) and stays in the layout flow behind the keyboard — only an
    // absolute footer floats above it
    if (!absoluteFooter) {
      footerView.translationY = 0f
      footerView.syncTranslationState()
      return
    }

    // The footer's absorbed safe-area inset rides below the keyboard's top
    // edge — its content stays flush with the keyboard without dropping the
    // inset padding from the layout, which would jump at the transition edges
    val keyboardShift = if (currentKeyboardInset > 0 && footerAvoidsKeyboard) {
      maxOf(0, currentKeyboardInset + footerKeyboardOffset - footerView.bottomInset)
    } else {
      0
    }

    val footerHeight = footerView.height
    val sheetHeight = sheet.height

    // Pinned to the screen bottom (above the keyboard) while the sheet sits at
    // or above its lowest stop; dragged past it the footer rides down with the
    // sheet instead, like iOS. A resize settle always pins — the sheet may be
    // animating up from below a stop that just grew
    val anchorTop = if (pendingDetentIndex >= 0) sheet.top else minOf(sheet.top, detentCalculator.getLowestSheetTop())
    val footerY = (sheetHeight - anchorTop - footerHeight - keyboardShift).toFloat()

    // Clamp to prevent footer going above safe area
    val maxAllowedY = (sheetHeight - topInset - footerHeight).toFloat()
    footerView.y = minOf(footerY, maxAllowedY)
    // Mid-motion slides are synced once the sheet settles or the keyboard
    // lands (handleStateSettled, keyboardDidShow/keyboardDidHide)
    if (!isSheetMoving) footerView.syncTranslationState()
    if (!footerAvoidsKeyboard) {
      containerView?.contentView?.updateContentInset()
    }
  }

  // =============================================================================
  // MARK: - Keyboard Handling
  // =============================================================================

  private fun shouldHandleKeyboard(checkFocus: Boolean = true): Boolean {
    if (wasHiddenByScreen) return false
    if (!isTopmostSheet) return false
    if (checkFocus && !isFocusedViewWithinSheet()) return false
    return true
  }

  fun saveFocusedView() {
    focusedViewBeforeBlur = delegate?.findRootContainerView()?.findFocus()
      ?: reactContext.currentActivity?.currentFocus
  }

  fun clearFocusedView() {
    focusedViewBeforeBlur = null
  }

  fun restoreFocusedView() {
    val viewToFocus = focusedViewBeforeBlur ?: return
    focusedViewBeforeBlur = null

    if (!viewToFocus.isAttachedToWindow) return
    if (viewToFocus.requestFocus()) {
      viewToFocus.postDelayed({
        if (viewToFocus.isFocused) KeyboardUtils.show(viewToFocus)
      }, 100)
    }
  }

  fun setupKeyboardObserver() {
    val coordinator = coordinatorLayout ?: run {
      RNLog.e(reactContext, "TrueSheet: coordinatorLayout is null in setupKeyboardObserver")
      return
    }
    cleanupKeyboardObserver()
    keyboardObserver = TrueSheetKeyboardObserver(coordinator, reactContext).apply {
      delegate = object : TrueSheetKeyboardObserverDelegate {
        override fun keyboardWillShow(height: Int) {
          if (!shouldHandleKeyboard()) return
          // If a resize is in flight, restore to its target — not the stale current
          detentIndexBeforeKeyboard = if (pendingDetentIndex >= 0) pendingDetentIndex else currentDetentIndex
          pendingDetentIndex = -1
          // Commit the target index first so the container grows before the sheet expands
          currentDetentIndex = detents.size - 1
          setupSheetDetents()
          positionFooter()
          updateDimAmount(animated = true)
        }

        override fun keyboardWillHide() {
          if (!shouldHandleKeyboard(checkFocus = false)) return
          // Mid-drag (the drag itself dismissed the keyboard) the release decides
          // the detent and a reconfigure would kill the gesture — the floor stops
          // stay put until the settle flushes the pending reconfigure
          if (interactionState is InteractionState.Dragging) {
            hasPendingSizeChange = true
            return
          }
          val restoring = !isBeingDismissed && detentIndexBeforeKeyboard >= 0
          if (restoring) {
            currentDetentIndex = detentIndexBeforeKeyboard
          }

          // A scroll-committed keyboard detent still holds the keyboard-shifted
          // top too — reconfigure so the sheet settles with the keyboard, once
          // any touch on the sheet lifts
          if (!isBeingDismissed && coordinatorLayout?.isTouchingSheet == true) {
            isKeyboardSettleDeferred = true
          } else if (!isBeingDismissed || isKeyboardDismissProgrammatic) {
            setupSheetDetents()
          }

          // Same-frame reposition — the reconfigure above shrinks the container
          // to the target detent, which yanks the bottom-pinned footer up until
          // the next keyboard animation frame repositions it.
          positionFooter()
          updateDimAmount(
            sheetTop = detentCalculator.getSheetTopForDetentIndex(currentDetentIndex),
            animated = true
          )
        }

        override fun keyboardDidShow(height: Int) {
          // The keyboard's last frame has positioned the footer
          containerView?.footerView?.syncTranslationState()
        }

        override fun keyboardDidHide() {
          containerView?.footerView?.syncTranslationState()
          if (!shouldHandleKeyboard(checkFocus = false)) return
          isKeyboardDismissProgrammatic = false
          // Keep detentIndexBeforeKeyboard for the settle's detent-change check
          if (interactionState is InteractionState.Dragging) {
            hasPendingSizeChange = true
            return
          }
          detentIndexBeforeKeyboard = -1
          if (!isKeyboardSettleDeferred) {
            setupSheetDetents(applyState = false)
          }
          positionFooter()
          updateDimAmount(
            sheetTop = detentCalculator.getSheetTopForDetentIndex(currentDetentIndex),
            animated = true
          )
        }

        override fun keyboardDidChangeHeight(height: Int) {
          // Skip focus check during active keyboard transitions (focus may be lost during hide)
          val skipFocusCheck = detentIndexBeforeKeyboard >= 0 || isKeyboardTransitioning
          if (!shouldHandleKeyboard(checkFocus = !skipFocusCheck)) return
          positionFooter()
        }

        override fun focusDidChange(newFocus: View) {
          // Handle case where keyboard is already visible and focus moves into the sheet
          if (!shouldHandleKeyboard()) return
          if (detentIndexBeforeKeyboard < 0 && (keyboardObserver?.currentHeight ?: 0) > 0) {
            detentIndexBeforeKeyboard = currentDetentIndex
            currentDetentIndex = detents.size - 1
            setupSheetDetents()
            positionFooter()
          }
        }
      }
      start()
    }
  }

  fun cleanupKeyboardObserver() {
    keyboardObserver?.stop()
    keyboardObserver = null
  }

  // =============================================================================
  // MARK: - Drag Handling
  // =============================================================================

  private fun getPositionDpForView(sheetView: View): Float =
    detentCalculator.getPositionDp(detentCalculator.getVisibleSheetHeight(sheetView.top))

  fun commitKeyboardDetent() {
    detentIndexBeforeKeyboard = -1
  }

  private fun handleSettling(sheetView: View) {
    // A keyboard-floor drag was released — the first settle frame reveals the target
    keyboardSettleStartTop = if (hasKeyboardFloor && interactionState is InteractionState.Dragging) sheetView.top else -1
  }

  /**
   * Dismisses the keyboard as soon as a released drag is known to land on a
   * keyboard-free stop, rather than waiting for the landing. BottomSheetBehavior
   * keeps its target private, so read it off the first settle frame: heading
   * down means the half stop or the floor; heading up from below the half stop
   * means the half stop; only heading up from above it means the expanded stop.
   */
  private fun dismissKeyboardForSettleTarget(sheetView: View) {
    if (keyboardSettleStartTop < 0) return
    val startTop = keyboardSettleStartTop
    keyboardSettleStartTop = -1

    val headingToKeyboardFreeStop = sheetView.top > startTop || startTop > detentCalculator.getKeyboardHalfStopTop()
    if (headingToKeyboardFreeStop && shouldHandleKeyboard()) dismissKeyboard()
  }

  private fun handleDragBegin(sheetView: View) {
    pendingDetentIndex = -1

    val position = getPositionDpForView(sheetView)
    val detent = detentCalculator.getDetentValueForIndex(currentDetentIndex)
    delegate?.viewControllerDidDragBegin(currentDetentIndex, position, detent)
    interactionState = InteractionState.Dragging(startTop = sheetView.top)
  }

  // Commits a non-keyboard detent and hides the keyboard; keyboardWillHide then
  // reconfigures the detents so the sheet settles at the committed index.
  private fun commitDetentAndDismissKeyboard(index: Int, sheetView: View) {
    val changed = index != knownDetentIndex
    detentIndexBeforeKeyboard = -1
    currentDetentIndex = index
    dismissKeyboard()
    setupDimmedBackground()

    if (!changed) return
    val position = getPositionDpForView(sheetView)
    val detent = detentCalculator.getDetentValueForIndex(index)
    delegate?.viewControllerDidChangeDetent(index, position, detent)
    this.sheetView?.updateGrabberAccessibilityValue(index, detents.size)
  }

  private fun handleDragChange(sheetView: View) {
    if (interactionState !is InteractionState.Dragging) return

    val position = getPositionDpForView(sheetView)
    val detent = detentCalculator.getDetentValueForIndex(currentDetentIndex)
    delegate?.viewControllerDidDragChange(currentDetentIndex, position, detent)
  }

  // =============================================================================
  // MARK: - Event Emission
  // =============================================================================

  private fun emitWillPresentEvents() {
    val (index, position, detent) = getDetentInfoWithValue(currentDetentIndex)
    parentSheetView?.viewControllerWillBlur()
    delegate?.viewControllerWillPresent(index, position, detent)
    delegate?.viewControllerWillFocus()
  }

  private fun emitWillDismissEvents() {
    delegate?.viewControllerWillBlur()
    delegate?.viewControllerWillDismiss()
    parentSheetView?.viewControllerWillFocus()

    // Dismissed mid-present: finishPresent() won't run. Settle the pending present well
    // before didDismiss so JS clears isPresenting and unmounts the lazy native view
    presentPromise?.invoke()
    presentPromise = null
  }

  private fun emitDidDismissEvents() {
    val parent = parentSheetView
    parentSheetView = null

    delegate?.viewControllerDidBlur()
    delegate?.viewControllerDidDismiss(parent)

    dismissPromise?.invoke()
    dismissPromise = null
  }

  private fun emitChangePositionDelegate(currentTop: Int, realtime: Boolean = true) {
    if (isPresented && !isPresentAnimating && !isBeingDismissed) {
      val index = detentCalculator.getBackgroundIndex(currentTop, displayedBackgroundIndex)
      if (index != displayedBackgroundIndex) {
        displayedBackgroundIndex = index
        setupBackground()
      }
    }
    // Dedupe emissions for same position
    if (currentTop == lastEmittedPositionPx) return

    lastEmittedPositionPx = currentTop
    val visibleHeight = realScreenHeight - currentTop
    val position = detentCalculator.getPositionDp(visibleHeight)
    val (interpolatedIndex, detent) = detentCalculator.getInterpolatedPositionInfo(currentTop)
    delegate?.viewControllerDidChangePosition(interpolatedIndex, position, detent, realtime)
  }

  /**
   * Updates position emission, footer, and dim amount together.
   * This pattern is commonly used during animations and state changes.
   */
  private fun updateSheetVisuals(effectiveTop: Int) {
    emitChangePositionDelegate(effectiveTop)
    positionFooter()
    updateDimAmount(effectiveTop)
  }

  // =============================================================================
  // MARK: - Detent Helpers
  // =============================================================================

  fun updateBehaviorMaxWidth() {
    val behavior = this.behavior ?: return
    val applyMaxWidth = maxContentWidth != null && !ScreenUtils.isPortraitPhone(reactContext)
    val newMaxWidth = if (applyMaxWidth) maxContentWidth!! else DEFAULT_MAX_WIDTH.dpToPx().toInt()
    if (behavior.maxWidth == newMaxWidth) return

    behavior.maxWidth = newMaxWidth
  }

  /**
   * Updates the Fabric state with the current/target detent size so Yoga sizes
   * the container to the sheet's visible height.
   */
  private fun updateStateDimensions() {
    if (detents.isEmpty()) return

    val targetIndex = (if (pendingDetentIndex >= 0) pendingDetentIndex else currentDetentIndex)
      .coerceIn(0, detents.size - 1)
    val maxAvailableHeight = realScreenHeight - topInset
    val newHeight = minOf(detentCalculator.getDetentHeight(detents[targetIndex]), maxAvailableHeight)
    val newWidth = getStateWidth()

    setStateDimensions(newWidth, newHeight)
  }

  /**
   * Tracks the sheet's visible height during drags and resize animations. Clamped to the
   * smallest detent — dragging below it slides the sheet out without resizing.
   */
  private fun updateStateDimensionsForPosition(sheetTop: Int) {
    if (detents.isEmpty()) return

    val maxAvailableHeight = realScreenHeight - topInset
    val minHeight = minOf(
      detentCalculator.getDetentHeight(detents.first(), includeKeyboard = !hasKeyboardFloor),
      maxAvailableHeight
    )
    val newHeight = detentCalculator.getVisibleSheetHeight(sheetTop).coerceIn(minHeight, maxAvailableHeight)

    setStateDimensions(getStateWidth(), newHeight)
  }

  private fun getStateWidth(): Int {
    val applyMaxWidth = maxContentWidth != null && !ScreenUtils.isPortraitPhone(reactContext)
    val effectiveMaxWidth = if (applyMaxWidth) maxContentWidth!! else DEFAULT_MAX_WIDTH.dpToPx().toInt()
    return minOf(screenWidth, effectiveMaxWidth)
  }

  private fun setStateDimensions(width: Int, height: Int) {
    if (lastStateWidth == width && lastStateHeight == height) return

    lastStateWidth = width
    lastStateHeight = height
    delegate?.viewControllerDidChangeSize(width, height)
  }

  /**
   * Realtime (non-animated) counterpart of TrueSheetStackManager.updateParentTranslation,
   * driven by onSlide so the parent tracks this sheet's actual position.
   */
  private fun syncParentTranslation(sheetTop: Int) {
    val parent = parentSheetView ?: return
    val minSheetTop = detentCalculator.getSheetTopForDetentIndex(0)
    parent.syncTranslationForChild(sheetTop, minSheetTop)
  }

  fun translateSheet(translationY: Int, animated: Boolean = true, onEnd: (() -> Unit)? = null) {
    val sheet = sheetView ?: return

    if (!animated) {
      sheet.animate().cancel()
      sheet.translationY = translationY.toFloat()
      emitChangePositionDelegate(sheet.top + translationY)
      onEnd?.invoke()
      return
    }

    sheet.animate()
      .translationY(translationY.toFloat())
      .setDuration(TRANSLATE_ANIMATION_DURATION)
      .setUpdateListener {
        val effectiveTop = sheet.top + sheet.translationY.toInt()
        emitChangePositionDelegate(effectiveTop)
      }
      .withEndAction { onEnd?.invoke() }
      .start()
  }

  private fun getDetentInfoWithValue(index: Int): Triple<Int, Float, Float> {
    val state = detentCalculator.getStateForDetentIndex(index)
    val detentIndex = detentCalculator.getDetentIndexForState(state) ?: 0
    val position = getPositionForDetentIndex(detentIndex)
    val detent = detentCalculator.getDetentValueForIndex(detentIndex)
    return Triple(detentIndex, position, detent)
  }

  private fun getPositionForDetentIndex(index: Int): Float {
    if (index < 0 || index >= detents.size) return screenHeight.pxToDp()

    sheetView?.let {
      val visibleSheetHeight = detentCalculator.getVisibleSheetHeight(it.top)
      if (visibleSheetHeight in 1..<realScreenHeight) {
        return detentCalculator.getPositionDp(visibleSheetHeight)
      }
    }

    val detentHeight = detentCalculator.getDetentHeight(detents[index])
    return detentCalculator.getPositionDp(detentHeight)
  }

  // =============================================================================
  // MARK: - RootView Implementation
  // =============================================================================

  override fun onInitializeAccessibilityNodeInfo(info: AccessibilityNodeInfo) {
    super.onInitializeAccessibilityNodeInfo(info)
    (getTag(R.id.react_test_id) as? String)?.let { info.viewIdResourceName = it }
  }

  // =============================================================================
  // MARK: - RootView Touch Handling
  // =============================================================================

  override fun onInterceptTouchEvent(event: MotionEvent): Boolean {
    eventDispatcher?.let {
      if (touchDeduper.shouldDispatch(event)) {
        jsTouchDispatcher.handleTouchEvent(event, it, reactContext)
      }
      jsPointerDispatcher.handleMotionEvent(event, it, true)
    }
    return super.onInterceptTouchEvent(event)
  }

  override fun requestDisallowInterceptTouchEvent(disallowIntercept: Boolean) {
    // Mirrors ReactSurfaceView: keep receiving onInterceptTouchEvent so
    // jsTouchDispatcher sees the gesture end, but forward the request up the tree.
    parent?.requestDisallowInterceptTouchEvent(disallowIntercept)
  }

  override fun onTouchEvent(event: MotionEvent): Boolean {
    eventDispatcher?.let {
      if (touchDeduper.shouldDispatch(event)) {
        jsTouchDispatcher.handleTouchEvent(event, it, reactContext)
      }
      jsPointerDispatcher.handleMotionEvent(event, it, false)
    }
    super.onTouchEvent(event)
    return true
  }

  override fun onInterceptHoverEvent(event: MotionEvent): Boolean {
    eventDispatcher?.let { jsPointerDispatcher.handleMotionEvent(event, it, true) }
    return super.onHoverEvent(event)
  }

  override fun onHoverEvent(event: MotionEvent): Boolean {
    eventDispatcher?.let { jsPointerDispatcher.handleMotionEvent(event, it, false) }
    return super.onHoverEvent(event)
  }

  override fun onChildStartedNativeGesture(childView: View?, ev: MotionEvent) {
    coordinatorLayout?.childDidClaimNativeGesture()
    eventDispatcher?.let {
      jsTouchDispatcher.onChildStartedNativeGesture(ev, it)
      jsPointerDispatcher.onChildStartedNativeGesture(childView, ev, it)
    }
  }

  override fun onChildEndedNativeGesture(childView: View, ev: MotionEvent) {
    eventDispatcher?.let { jsTouchDispatcher.onChildEndedNativeGesture(ev, it) }
    jsPointerDispatcher.onChildEndedNativeGesture()
  }

  override fun handleException(t: Throwable) {
    reactContext.reactApplicationContext.handleException(RuntimeException(t))
  }
}
